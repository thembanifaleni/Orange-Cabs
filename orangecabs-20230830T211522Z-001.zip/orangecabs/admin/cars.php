<?php 
    session_start();

    include('../func/connection.php');
    
    if (isset($_SESSION['user_id'])) {

      $user_id = $_SESSION['user_id'];

      //get username and email
      $sql = "SELECT * FROM users WHERE user_id='$user_id'";

      $result = mysqli_query($link, $sql);

      $count = mysqli_num_rows($result);

      if ($count == 1) {

      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

      $username = $row['username'];
      $mobile = $row['mobile'];
      $email = $row['email'];
      $profile = $row['profilepicture'];

      $_SESSION['username'] = $username;
      $_SESSION['mobile'] = $mobile;
      $_SESSION['email'] = $email;
      $_SESSION['profile'] = $profile;

      } else {

      echo "There was an error retrieving the username and email from the database!";

      }

    }

    $p = 'cars';
    
    include('header.php'); 

?>

<div class="row dashboard">

    <div class="col s12 m4 l3 margin-left">
        <?php $p = 'cars'; include('sidebar.php');?>
    </div>

    <div class="col s12 m8 l9"> 

        <!-- Section: users -->
      <section class="section section-stats center">
          <div class="row">
            <div class="col s12 m6 l12">
                <h4 class="madmin-title"><span >Cars</span></h4>

<table class="striped" id="datatable" style="width:inherit !important;">
                                <thead>
                                    <tr>
                                    <th>Picture</th>
                                    <th>Car Model</th>
                                    <th>Car brand</th>
                                    <th>Registration Num.</th>
                                    <th>Licence Num.</th>
                                    <th>Seat Available</th>                                   
                                    <th>Color</th>
                                    <th>Rate/Km</th>
                                    <th>Driver</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                    
                                    </tr>
                                </thead>

                                <tbody class="loadcars">
                                    
                <?php
                                        // include('../../func/connection.php');
                                        
                                        $sqlcars = "SELECT * FROM cars 
                                            INNER JOIN model_car 
                                            ON cars.vehicule_model = model_car.modelcar_id
                                            INNER JOIN brand_car
                                            ON cars.vehicule_brand = brand_car.brandcar_id
                                            INNER JOIN users
                                            ON cars.driver_id = users.user_id
                                            INNER JOIN colorcar
                                            ON cars.vehicule_color = colorcar.colorcar_id ORDER BY car_id DESC";
                                            

                                        if($result = mysqli_query($link, $sqlcars)){

                                            if(mysqli_num_rows($result)>0){

                                                while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
                                                $car_id = $row['car_id'];
                                                $modelcar = $row['title'];
                                                $brand_car = $row['brand_title'];
                                                $vehiculeRegistration = $row['vehicule_registration'];
                                                $vehiculeLicenceN = $row['vehicule_licenceN'];
                                                $seatavailable = $row['seatavailable'];
                                                $vehiculeColor = $row['colorcar_title'];
                                                $rateperkm = $row['rate_per_km'];
                                                $driver = $row['username'];
                                                $statusCar = $row['status_car'];
                                                $date = $row['date_add'];
                                                $profile = $row['picture'];          
                                    ?>
                                    <tr>
                                        <td>
                                            <a href="#picturecars-modal" class="modal-trigger btn-floating blue" data-car-id="<?php echo $car_id ?>">
                                                <?php 
                                                    if(empty($profile)) {
                                                        echo "
                                                        <i class=\"material-icons\">system_update_alt</i> 
                                                        ";
                                                    }
                                                    else {
                                                        echo "<i class=\"material-icons\"><img src='$profile'></i>";
                                                    }     
                                                ?>
                                            </a>
                                        </td>
                                        <td><?php echo  $modelcar; ?></td>
                                        <td><?php echo $brand_car;?></td>
                                        <td><?php echo $vehiculeRegistration; ?></td>
                                        <td><?php echo $vehiculeLicenceN; ?></td>
                                        <td><?php echo $seatavailable; ?></td>
                                        <td><?php echo $vehiculeColor; ?></td>
                                        <td><?php echo $rateperkm;?></td>
                                        <td><?php echo $driver;?></td>
                                        <td><?php echo $date;?></td>
                                        <td>
                                        <button href="#" class="modal-trigger btn-floating blue" data-car_id="<?php echo $car_id ;?>">
                                            <i class="material-icons">create</i>
                                        </button>
                                        <!-- <button  class="delete-row btn-floating red" data-car_id="<?php echo $car_id ;?>"> -->
                                            <!-- <i class="material-icons">delete</i> -->
                                        <!-- </button> -->

                                          <form id="deleteCarForm" >
                                                <input type="hidden" id="deleteCarForm" value=<?php echo '"' .  $car_id . '"'; ?> name = "car_id">
                                                <button class="btn-floating red" >
                                                    <!-- <input type="submit" value="X"> -->X
                                                </button>
                                            </form>
                                        </td>
                                        
                                    </tr>
                                    <?php
                                    }
                                    }
                                    }
                                    ?>                                
                                    
                                </tbody>
                </table>
                

            </div>
          </div>
      </section>

    </div>
</div>

