<?php 

    session_start();

    include('../func/connection.php');
    
    if (isset($_SESSION['user_id'])) {

      $user_id = $_SESSION['user_id'];

    }

    $p = 'drivers';
    
    include('header.php'); 

?>

<div class="row dashboard">

    <div class="col s12 m4 l3 margin-left">
        <?php $p = 'drivers'; include('sidebar.php');?>
    </div>

    <div class="col s12 m8 l9"> 

        <!-- Section: drivers -->
      <section class="section section-stats center">
          <div class="row">
            <div class="col s12 m6 l12">
              <h4 class="madmin-title"><span >Drivers</span></h4>
                <table class="striped" id="datatable">
                    <thead>
                        <tr>
                        <th>Driver Name</th>
                        <th>User name</th>
                        <th>Pickup address</th>
                        <th>Drop address</th>
                        <th>Amount</th>
                        <th>Payment status</th>
                        <th>status</th>
                        <th>Action</th>
                        
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        include('../func/connection.php');
                        $sql = "SELECT * FROM users";

                        if($result = mysqli_query($link, $sql)){

                            if(mysqli_num_rows($result)>0){

                                while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
                                    $user_id = $row['user_id'];
                                    $username = $row['username'];
                                    $mobile = $row['mobile'];
                                    $email = $row['email'];
                                    $role = $row['role'];
                                    $verify = $row['verify'];
                                    $profile = $row['profilepicture'];          
                        ?>
                        <tr>
                        
                            <td><?php echo $username ; ?></td>
                            <td><?php echo $mobile; ?></td>
                            <td><?php echo $email; ?></td>
                            <td>
                                <?php 
                                if($verify == "0") {
                                    echo "
                                        Pending 
                                    ";
                                }
                                else {
                                    echo "active";
                                }
                                
                            ?>
                            </td>
                            <td>

                                <?php 
                                if($role == "admin") {
                                    echo "
                                        Admin 
                                    ";
                                }
                                else {
                                    echo "-";
                                }
                                
                            ?>

                            </td>
                            
                            <td>1</td>
                            <td>1</td>
                            <td>
                            <a href="#" class="modal-trigger btn-floating #81d4fa light-blue lighten-3" data-user-id="$user_id">
                                More
                            </a>
                            </td>
                            
                        </tr>
                        <?
                        }
                        }
                        }
                    ?>                                                
                        
                    </tbody>
                </table>
            </div>
          </div>
      </section>

    </div>
</div>

