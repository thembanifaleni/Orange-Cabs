<nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">OrangeMadmin</a>

      <div class="btn-group">
  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Logged in as <?php if(isset($_SESSION['username'])){echo $_SESSION['username'];} ?> 
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="#">
        <?php 
                        if (!isset($_SESSION['profile'])) {

                            echo "<img src='profilepicture/carprofile.png'  class='profile'>";

                        } else {

                            echo "<img src='".$_SESSION['profile']."' class='profile'>";


                        }
                    ?>
    </a>
    <a class="dropdown-item" href="#">Change profile</a>
    
    <div class="dropdown-divider"></div>
        <!-- <a class="dropdown-item" href="#">Separated link</a> -->
        <a class="dropdown-item" href="../index.php?logout=1">LOGOUT</a>
    </div>

    </div>

    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap enable-notification">
          <a class="nav-link" href="#"><i class="fa fa-bell"></i></a>
        </li>
    </ul>

</nav> 




   
  