//Ajax Call for the add car form 
//Once the form is submitted
$("#addcarsform").submit(function(event){ 
    //prevent default php processing
    event.preventDefault();
    //collect user inputs
    var datatopost = $(this).serializeArray();
//    console.log(datatopost);
    //send them to signup.php using AJAX
    $.ajax({
        url: "funcadmin/addcars.php",
        type: "POST",
        data: datatopost,
        success: function(data){
            if(data){
                $("#addcarsResult").html(data);
                // //hide modal
                
                setTimeout(function(){
                    $("#addcarsform")[0].reset();
                },3000);

                setTimeout(function(){
                    $("#addcarsResult").hide();
                },3000);

                // setTimeout(function(){
                //     allcars();
                // },3000);

                // allcars();

                // setTimeout(function(){
                //     $("#cars-modal").hide();
                // },3000);
            }
        },
        error: function(){
            $("#addcarsResult").html("<div class='red' style='color:#fff;'>There was an error with the Ajax Call. Please try again later.</div>");
            
        }
    
    });

});


//Delete cars
$("#deleteCarForm").submit(function(event) {
    event.preventDefault();
    data = $(this).serializeArray();
    // console.log(data);
    $.ajax({
        url: 'funcadmin/deletecars.php',
        method: 'POST',
        data: data,
        success: function(data){

            if(data){

                window.alert("<div class='alert alert-danger'>The trip could not be deleted. Please try again!</div>");
            
            }else{

                setTimeout(function(){
                    location.reload();
                },3000);

            }

        },
        error: function(){
            window.alert("<p>There was an error with the Ajax Call. Please try again later.</p>")
        }
    });
    
});
    

//Ajax Call for the add driver form
//Once the form is submitted
$("#adddriverform").submit(function(event){ 
    //prevent default php processing
    event.preventDefault();
    //collect user inputs
    var datatopost = $(this).serializeArray();
//    console.log(datatopost);
    //send them to login.php using AJAX
    $.ajax({
        url: "funcadmin/adddriver.php",
        type: "POST",
        data: datatopost,
        success: function(data){

            $("#adddriverResult").html(data);
               
                setTimeout(function(){
                    $("#adddriverform")[0].reset();
                },3000);

                setTimeout(function(){
                    $("#adddriverResult").hide();
                },3000);

                 // //hide modal
                // setTimeout(function(){
                //     location.reload();
                // },3000);
        },
        error: function(){
            $("#adddriverResult").html("<div class='red' style='color:#fff;'>There was an error with the Ajax Call. Please try again later.</div>");
            
        }   
    });
});


//update picture preview
var file, imageType,imageName,imageSize;
var wrongType;

$("#picture").change(function(){

    file = this.files[0];
    // console.log(file);
    imageType = file.type;
    imageSize = file.size;
    imageName = file.name;

    //check image type
    var acceptableType = ["image/jpeg", "image/png", "image/jpg"];

    wrongType = ($.inArray(imageType,acceptableType) == -1);

    if(wrongType){

        $("#updatepicturemessage")
        .php("<div class='red' style='color:#fff;'>Only jpeg, png and jpg are accepted !.</div>");

        return false;
    }

    //check image size is super 3 mega byte(Mo)
    if(imageSize > 3*1024*1024){

        $("#updatepicturemessage")
        .php("<div class='class='red' style='color:#fff;'>Please upload an image less than 3Mo !.</div>");

        return false;
    }

    //fileReader object will be used to convert the image in a binary string
    var reader = new FileReader();

    //callback 
    reader.onload = updatePreviewPicture;

    //start read operation = convert content into a data url
    reader.readAsDataURL(file);

});

// updatePreviewPicyure function
function updatePreviewPicture(event){
    // console.log(event);
    $("#imagePreview").attr("src", event.target.result);
}

// //upload file 
$("#profilepictureform").submit(function(){
    //prevent default php file
    event.preventDefault();

    //file missing
    if(!file){

        $("#updatepicturemessage")
        .php("<div class='red' style='color:#fff;'>Please upload a picture !.</div>");

        return false;

    }

    //check if image type is wrong
    if(wrongType){

        $("#updatepicturemessage")
        .php("<div class='red' style='color:#fff;'>Only jpeg, png and jpg are accepted !.</div>");

        return false;
    }

    //check if image is to big
    if(imageSize > 3*1024*1024){

        $("#updatepicturemessage")
        .php("<div class='red' style='color:#fff;'>Please upload an image less than 3Mo !.</div>");

        return false;
    }

    //show file uploaded in the console
    // var test = new FormData(this);
    // console.log(test.get("picture"));

    //call ajax
    $.ajax({
        url:"updatepicture.php",
        method: "POST",
        data: new FormData(this),
        contentType: false, // contentType:" application/json ; charset=utf-8",
        cache: false,
        processData: false,
        success: function(data){

            if(data){

                $("#updatepicturemessage")
                .php(data);

                setTimeout(function(){
                    $("#profilepictureform")[0].reset();
                },3000);

                setTimeout(function(){
                    $("#updatepicturemessage").hide();
                },3000);

            }else{
                
                location.reload();
            }

        },
        error: function(){

            $("#updatepicturemessage")
            .php("<div class='red' style='color:#fff;'>There was an error with the Ajax Call. Please try again later.</div>");
        }
    });
});

//get all cars
// function allcars(){
//      //send  AJAX call to gettrips.php
//      $.ajax({
//         url: "funcadmin/loadcars.php",
//         success: function (returnedData) {
//             // console.log(returnedData);
//             if (returnedData) {

//                 $(".loadcars").html(returnedData);

//             } else {

//                 $(".loadcars").html("<div class='red' style='color:#fff;'>Not cars created yet!.</div>");
//             }

//         },
//         error: function () {

//             $(".loadcars").html("<div class='alert alert-danger'>There was an error with the Ajax Call. Please try again later.</div>");

//         }
//     });
// }
// //call function
// allcars();

  //dataTable
  $("#datatable").dataTable({
    // "processing": true,
    // "serverSide": true,
    // "ajax": {
    //     "url": "scripts/post.php",
    //     "type": "POST"
    // },
    // "columns": [
    //     { "data": "first_name" },
    //     { "data": "last_name" },
    //     { "data": "position" },
    //     { "data": "office" },
    //     { "data": "start_date" },
    //     { "data": "salary" }
    // ]
  });

  //update driver
// $("#updatedriver-modal").leanModal(function(event){
//     $("#updatedriverResult").empty();
//     var invoker = $(event.relatedTarget);
//     console.log(invoker);

//     //ajax call to get details for the trip
//     $.ajax({
//         url: "funcadmin/updatedriver.php.php",
//         type: "POST",
//         //we need to send the trip_id of the trip 
//         data: {user_id: invoker.data('user_id')},
//         success: function (data){ 
//             if(data){

//                 if(data == 'error'){

//                     $('#edittripmessage').text("There was an error with the Ajax Call. Please try again later.");

//                 }else{

//                      //passe json data in array data
//                     trip = JSON.parse(data);
//                     //fill tedit trip form using the JSON parsed data
//                     // console.log(trip);
//                     formatModal();
                    
//                 }
//             }
           
//         },
//         error: function(){
//             $('#edittripmessage').text("There was an error with the Ajax Call. Please try again later.");

//         }

//     });

//     //submit form for updating
//     $("#Edittripform").submit(function(event){
//         $("#edittripmessage").empty();
//         event.preventDefault();
//         data = $(this).serializeArray();
//         data.push({name:'trip_id', value:invoker.data('trip_id')});
//         geocodingEditTrip();
//     });

//     //delete a trip
//     $("#deleteTrip").click(function(){
//         //ajax call to get details for the trip
//         $.ajax({
//             url: "deletetrip.php",
//             type: "POST",
//             //we need to send the trip_id of the trip 
//             data: {trip_id: invoker.data('trip_id')},
//             success: function (returnedData){ 

//                 if(returnedData){

//                     $('#edittripmessage').html("<div class='alert alert-danger'>The trip could not be deleted. Please try again!</div>");
//                 }else{
//                      //hide modal
//                     setTimeout(function(){
//                         $('#edittripModal').modal('hide');
//                     },3000);

//                     //load trips
                    
//                     setTimeout(function(){
//                         getTripsRecents();
//                     },3000);

//                     setTimeout(function(){
//                         getTripsRecents();
//                     },3000);
//                     setTimeout(function(){
//                         getAllBookings();
//                     },3000);
//                     setTimeout(function(){
//                         getHistoryTrip();
//                     },3000);
//                 }
            
//             },
//             error: function(){
//                 $('#edittripmessage').text("");

//             }

//         });
//     });

// });
