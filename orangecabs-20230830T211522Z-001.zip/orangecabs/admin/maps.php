<?php 
    session_start();

    include('../func/connection.php');
    
    if (isset($_SESSION['user_id'])) {

      $user_id = $_SESSION['user_id'];

      //get username and email
      $sql = "SELECT * FROM users WHERE user_id='$user_id'";

      $result = mysqli_query($link, $sql);

      $count = mysqli_num_rows($result);

      if ($count == 1) {

      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

      $username = $row['username'];
      $mobile = $row['mobile'];
      $email = $row['email'];
      $profile = $row['profilepicture'];

      $_SESSION['username'] = $username;
      $_SESSION['mobile'] = $mobile;
      $_SESSION['email'] = $email;
      $_SESSION['profile'] = $profile;

      } else {

      echo "There was an error retrieving the username and email from the database!";

      }

    }

    $p = 'madmin';
    
    include('header.php'); 

    // include('../func/connection.php');

//count users registed
    $sql = "SELECT COUNT(*) FROM users";
    $result = mysqli_query($link,$sql);
    $rows = mysqli_fetch_row($result);
    // return $rows[0];
    $number_of_users = $rows[0];

    //count bookings
    $sqluser = "SELECT COUNT(*) FROM trips";
    $result = mysqli_query($link,$sqluser);
    $rows = mysqli_fetch_row($result);
    // return $rows[0];
    $number_of_bookings = $rows[0];

    //count chat
    $sqlchat = "SELECT COUNT(*) FROM chat";
    $result = mysqli_query($link,$sqlchat);
    $rows = mysqli_fetch_row($result);
    // return $rows[0];
    $number_of_chat = $rows[0];

    $sqlhistory = "SELECT COUNT(*) FROM history_book";
    $result = mysqli_query($link,$sqlhistory);
    $rows = mysqli_fetch_row($result);
    // return $rows[0];
    $number_of_history = $rows[0];
?>

<div class="row dashboard">

    <div class="col s12 m4 l3 margin-left">
        <?php $p = 'madmin'; include('sidebar.php');?>
    </div>

    <div class="col s12 m8 l9"> 

        <!-- Section: Stats -->
      <section class="section section-stats center">
          <div class="row">
            <div class="col s12 m6 l3">
              <div class="card-panel blue lighten-1 white-text center">
                <i class="material-icons medium">insert_emoticon</i>
                <h5>Monthly Book</h5>
                <h3 class="count"><?=$number_of_history;?></h3>
                <div class="progress grey lighten-1">
                  <div class="determinate white" style="width: 40%;"></div>
                </div>
              </div>
            </div>
            <div class="col s12 m6 l3">
              <div class="card-panel center">
                <i class="material-icons medium">mode_edit</i>
                <h5>Book Riders</h5>
                <h3 class="count"><?=$number_of_bookings;?></h3>
                <div class="progress grey lighten-1">
                  <div class="determinate blue lighten-1" style="width: 20%;"></div>
                </div>
              </div>
            </div>
            <div class="col s12 m6 l3">
              <div class="card-panel blue lighten-1 white-text center">
                <i class="material-icons medium">mode_comment</i>
                <h5>Chat</h5>
                <h3 class="count"><?=$number_of_chat;?></h3>
                <div class="progress grey lighten-1">
                  <div class="determinate white" style="width: 40%;"></div>
                </div>
              </div>
            </div>
            <div class="col s12 m6 l3">
              <div class="card-panel center">
                <i class="material-icons medium">supervisor_account</i>
                <h5>Users</h5>
                <h3 class="count"><?=$number_of_users;?></h3>
                <div class="progress grey lighten-1">
                  <div class="determinate blue lighten-1" style="width: 10%;"></div>
                </div>
              </div>
            </div>
      </div>
      </section>


      <!-- Section: maps -->
      <section class="section section-visitors blue lighten-4">
        <div class="row">
          <div class="col s12 m6 l12">
            <div class="card-panel">
              <div id="map" style="height: 400px; width: 100%;"></div>
            </div>
          </div>
        </div>
      </section>

     

    </div>
</div>

