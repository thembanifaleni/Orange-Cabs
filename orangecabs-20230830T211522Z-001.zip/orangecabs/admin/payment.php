<?php 
    session_start();

    include('../func/connection.php');
    
    if (isset($_SESSION['user_id'])) {

      $user_id = $_SESSION['user_id'];

      //get username and email
      $sql = "SELECT * FROM users WHERE user_id='$user_id'";

      $result = mysqli_query($link, $sql);

      $count = mysqli_num_rows($result);

      if ($count == 1) {

      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

      $username = $row['username'];
      $mobile = $row['mobile'];
      $email = $row['email'];
      $profile = $row['profilepicture'];

      $_SESSION['username'] = $username;
      $_SESSION['mobile'] = $mobile;
      $_SESSION['email'] = $email;
      $_SESSION['profile'] = $profile;

      } else {

      echo "There was an error retrieving the username and email from the database!";

      }

    }

    $p = 'payment';
    
    include('header.php'); 

?>

<div class="row dashboard">

    <div class="col s12 m4 l3 margin-left">
        <?php $p = 'payment'; include('sidebar.php');?>
    </div>

    <div class="col s12 m8 l9"> 

        <!-- Section: users -->
      <section class="section section-stats center">
          <div class="row">
            <div class="col s12 m6 l12">
            <section class="section section-stats center">
          <div class="row">
            <div class="col s12 m6 l12">
              <h4 class="madmin-title"><span >Payments</span></h4>


               <div class="row">
                <div class="col s12 m6 l4">
                    <div class="input-field">
                      <input type="text" id="vehiculeModel" name="vehiculeModel">
                      <label for="vehiculemodel">Vehicule Model</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                    <div class="input-field">
                        <input type="text" id="vehiculeColor" name="vehiculeColor">
                        <label for="vehiculeColor">Vehicule Color</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                  <div class="input-field">
                      <input type="number" id="vehiculeRegistrationN" name="vehiculeRegistrationN">
                      <label for="vehiculeRegistrationN">Vehicule Registration Num.</label>
                  </div>
                </div>

            </div>

            <div class="row">
                <div class="col s12 m6 l4">
                    <div class="input-field">
                      <input type="text" id="vehiculeBrand" name="vehiculeBrand">
                      <label for="vehiculeBrand">Vehicule Brand</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                    <div class="input-field">
                        <input type="text" id="LicenceNum" name="LicenceNum">
                        <label for="LicenceNum">Vehicule Num.</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                  <div class="input-field">
                      <input type="number" id="seatavailable" name="seatavailable">
                      <label for="title">Seat Available</label>
                  </div>
                </div>

            </div>

            <div class="row">
                <div class="col s12 m6 l4">
                    <div class="input-field">
                      <input type="text" id="vehiculeBrand" name="vehiculeBrand">
                      <label for="vehiculeBrand">Vehicule Brand</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                    <div class="input-field">
                        <input type="text" id="LicenceNum" name="LicenceNum">
                        <label for="LicenceNum">Vehicule Num.</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                  <div class="input-field">
                      <select>
                          <option value="" disabled="disabled" selected="selected">Choose your option</option>
                          <option value="1">Option 1</option>
                          <option value="2">Option 2</option>
                          <option value="3">Option 3</option>
                      </select>
                      <label>Materialize Select</label>
                  </div>

                </div>
            </div>
            </div>
          </div>
      </section>

            </div>
          </div>
      </section>

    </div>
</div>

<script>
      $(document).ready(function() {
    $('select').material_select();
});
</script>