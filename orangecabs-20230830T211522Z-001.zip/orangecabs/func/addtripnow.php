        <div class="row">
            <!-- sidebar navigation -->
            <? $p='booknow'; include('../inc/sidebar.php');?>

            <!-- content bookings-->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Online Bookings / Book now </h1>
                    <!-- <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group mr-2">
                        <button class="btn btn-sm btn-outline-secondary">Share</button>
                        <button class="btn btn-sm btn-outline-secondary">Export</button>
                    </div>
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                        <span data-feather="calendar"></span>
                        This week
                    </button>
                    </div> -->
                </div>
                <form action="" id="addTripform">

                    <div class="modal-body">

                        <!-- <div id="map"></div>
                        <div id="infowindow-content">
                            <img src="" width="16" height="16" id="place-icon">
                            <span id="place-name"  class="title"></span><br>
                            <span id="place-address"></span>
                        </div> -->
                        <div id="addtripmessage"></div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="pickuppoint" class="label-form">PICK UP POINT:</label>
                                <input type="text" class="form-control text-lowercase" id="pickuppoint"  name="pickuppoint" placeholder="PICK UP POINT:">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="dropofpoint" class="label-form">DROP-OFF POINT:</label>
                                <input type="text" class="form-control text-lowercase" id="dropofpoint" placeholder="DROP-OFF POINT:" name="dropofpoint">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-4">
                                    <label for="distance" class="label-form">DISTANCE:</label>
                                    <input type="text" class="form-control text-lowercase" id="distance"  readonly="readonly" name="distance" placeholder="DISTANCE:">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="duration" class="label-form">DURATION:</label>
                                    <input type="text" class="form-control text-lowercase" id="duration" readonly="readonly" placeholder="DURATION:" name="duration">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="price" class="label-form">PRICE:</label>
                                    <input type="text" class="form-control text-lowercase" id="price" readonly="readonly" placeholder="Price:" name="price">
                                </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-4">
                            <label for="date" class="text-uppercase label-form">Select Date & Time Pick up:</label>
                                <div id="picker"> </div>
                                <input class="form-control " type="hidden" id="result" value="" name="date" id="date"/>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="amountofriders" class="text-uppercase label-form">Amount of riders:</label>
                                <input type="number" class="form-control text-lowercase" id="amountofriders" name="amountofriders" placeholder="Amount off riders:">
                            </div>
                            <div class="form-group col-md-4">
                                <label for="nameofonerider" class="text-uppercase label-form">Name of one rider:</label>
                                <input type="text" class="form-control text-lowercase" id="nameofonerider" placeholder="Name of one rider:" name="nameofonerider">
                            </div>

                        </div>

                    </div>

                    <div class="modal-footer">
                        <input type="submit" class="btn btn-primary" name="addtrip" value="Book and Go">
                    </div>
                </form>

            </main>      
        </div>           
            