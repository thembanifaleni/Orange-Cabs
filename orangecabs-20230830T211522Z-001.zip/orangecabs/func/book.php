
       <div class="row">
            <!-- sidebar navigation -->
            <? //$p='search'; include('../inc/sidebar.php');?>

            <!--Notification-->
 
            <!-- content bookings-->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Online Bookings / Search  Trip</h1>
                </div>

                <div class="container">
 
                <nav class="navbar navbar-inverse">

                

                <div class="container-fluid">

                <div class="navbar-header">
                
                    <a class="navbar-brand" href="#">PHP Notification Tutorial</a>

                </div>

               <!-- bell div-->
            <div class="bell">
            
                <ul class="nav navbar-nav navbar-right">

                    <li class="dropdown">
        
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <span class="label label-pill label-danger count" style="border-radius:10px;"></span>
                        <span class="tooltiptext">Enable Notification</span>
                        <span onclick="notifyMe()" class="glyphicon glyphicon-bell"  style="font-size:18px;"></span>
        
                    </a>

            
                    <ul class="dropdown-menu"></ul>

                    </li>

                </ul>
              </div>
                </div>
                <!--close bell div-->

                </nav>

                <br />

                <form method="post" id="comment_form">

                <div id="notificationMessage"></div>
                <div class="form-group">


                <label>Enter Subject</label>

                <input type="text" name="subject" id="subject" class="form-control">

                </div>

                <div class="form-group">

                <label>Enter Comment</label>

                <textarea name="comment" id="comment" class="form-control" rows="5"></textarea>

                </div>

                <div class="form-group">

                    <input type="submit" name="post" id="post" class="btn btn-info" value="Post" />

                </div>
                <div id="text"> </div>

                </form>

                <!-- <div class="" id=d
                        <form id="seard
                            <div classd
                                <div cd
                                    <ld>PICK UP POINT:</label>
                                    <idid="pickuppoint" placeholder="PICK UP POINT:" name="pickuppoint">
                                </div>d
                                <div cd
                                    <ld>DROP-OFF POINT:</label>
                                    <idid="dropofpoint" placeholder="DROP-OFF POINT:" name="dropofpoint">
                                </div>d
                                <div cd
                                    <bdcess btn-lg" style="margin-top: -.5rem;">Search</button>
                                </div>d
                            </div>
                        </form> -->


                        <!-- trips -->
                        <!-- <div id="d
                        
                      
                         <div id="map"></div>
                        <div id="infowindow-content">
                            <img src="" width="16" height="16" id="place-icon">
                            <span id="place-name"  class="title"></span><br>
                            <span id="place-address"></span>
                        </div>
                </div> -->
            </main>      
        </div>



<script>

function notifyMe(message) {
if (message == undefined) {
message = "Notofication enabled";
};


var message = "notification enabled"

function notifyMe() {
 
  if (!("Notification")) {
    alert("This browser does not support desktop notification");
  }

  
  else if (Notification.permission === "granted") {
    var notification = new Notification(message);
  }

  
  else if (Notification.permission !== "denied") {
    Notification.requestPermission().then(function (permission) {
      if (permission === "granted") {
        var notification = new Notification(message);
        
      }
    });
  } 

</script>

<script>
$$(function() {
    $( "#show-option" ).tooltip({
        show: {
        effect: "slideDown",
        delay: 300
        }
    });
});
</script>

<style>


.bell .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: #555;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    bottom: 125%;
    left: 50%;
    margin-left: -60px;
    opacity: 0;
    transition: opacity 0.3s;
}

.tooltip .tooltiptext::after {
    content: "";
    position: absolute;
    top: 100%;
    left: 50%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #555 transparent transparent transparent;
}

.bell :hover .tooltiptext {
    visibility: visible;
    opacity: 1;
}


</style>

