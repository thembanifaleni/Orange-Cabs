<?php
session_start();
include('connection.php');

//get the user_id
$user_id = $_SESSION['user_id'];

?>
    
    
    <table class="table-striped" id="datatable">
                    <thead>
                        <tr>
                        <th>Pick up point</th>
                        <th>Drop of point</th>
                        <th>Price/ Rand</th>
                        <th>Distance</th>
                        <th>Duration</th>
                        <th>Amount of riders</th>
                        <th>Name of one rider</th>
                        <th>Date & time pickup</th>
                        <th>Status pay</th>
                        <th>Actions</th>
                        
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        
                        //run a query to look for notes corresponding to user_id
                          $sql = "SELECT * FROM trips WHERE user_id ='$user_id' AND trips.date >= DATE(NOW()) AND is_delete='0' AND status_pay='unpaid' ORDER BY trip_id DESC";

                          //shows trips or alert message
                          if($result = mysqli_query($link, $sql)){

                              if(mysqli_num_rows($result)>0){

                                  while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
                                      $origine = $row['departure'];
                                      $destination = $row['destination'];
                                      $amountofriders = $row['amountofriders'];
                                      $nameofonerider = $row['nameofonerider'];
                                      $distance = $row['distance'];
                                      $duration = $row['duration'];
                                      $price = $row['price'];
                                      $status = $row['status_pay'];
                                      $date = date('D d M, Y h:i', strtotime($row['date']));
                                      $trip_id = $row['trip_id'];
                                    
                        ?>
                        <tr>
                        
                            <td><?php echo $origine ; ?></td>
                            <td><?php echo $destination; ?></td>
                            <td><?php echo "<strong>R</strong>".$price; ?></td>
                            <td><?php echo $distance; ?></td>
                            <td><?php echo $duration. "'"; ?></td>
                            <td><?php echo $amountofriders; ?></td>
                            <td><?php echo $nameofonerider; ?></td>
                            <td><?php echo $date; ?></td>
                            <td>
                                <?php 
                                if($status == "unpaid") {
                                    echo "
                                         <span class=\"alert alert-warning\">Unpaid</span>
                                    ";
                                }
                                else {
                                    echo "<span class=\"alert alert-success\">Paid</span>";
                                }
                                
                            ?>
                            </td>

                            <td>
                              <div class="btn-group" role="group" aria-label="Third group">
                                  <button type="button" class="btn btn-success" data-toggle='modal' data-target='#edittripModal' data-trip_id='<?php echo $trip_id?>'>Edit</button>
                              </div>

                              <!-- <div class="btn-group" role="group" aria-label="Third group"> -->
                                  <button type="button" id='paypal-button' data-trip_id='$trip_id'  id='paypal-button' data-user_id="<?php echo $user_id?>">Pay</button>
                              <!-- </div> -->
                            </td>  
                        </tr>
                        <?
                        }
                      }else{
                          echo '<div class="alert alert-warning">You have not history avalaible yet!</div>'. mysqli_error($link); exit;
                      }
                      
                  }else{  
                  
                      echo '<div class="alert alert-warning">An error occured!</div>'; exit;
                  
                  }
                    ?>                                                
                        
           </tbody>
    </table>

<script>
  paypal.Button.render({
    // Configure environment
    env: 'sandbox',
    client: {
      sandbox: 'demo_sandbox_client_id',
      production: 'demo_production_client_id'
    },
    // Customize button (optional)
    locale: 'en_US',
    style: {
      size: 'small',
      color: 'gold',
      shape: 'pill',
    },
    // Set up a payment
    payment: function(data, actions) {
      return actions.payment.create({
        transactions: [{
          amount: {
            total: '0.01',
            currency: 'USD'
          }
        }]
      });
    },
    // Execute the payment
    onAuthorize: function(data, actions) {
      return actions.payment.execute().then(function() {
        // Show a confirmation message to the buyer
        window.alert('Thank you for your purchase!');
      });
    }
  }, '#paypal-button');

</script>

     


