<?php 

session_start();

if (!isset($_SESSION['user_id'])) {

    header("Location:../index.php");
}

?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
    <!-- Bootstrap CSS -->

     <link href="../src/css/datetimepicker.css" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css"> -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Orange Cabs | My Trips</title>
  <link rel="shortcut icon" type="image/ico" href="../favicon.ico" />

   <style>
    html,body{
        height: 100%;
        overflow-x: hidden;
        position: relative;
    }
    body{
     background: url(../src/images/onlinebook.jpg);
     background-size: cover;
     color:#fff;
     position: relative;
     height: 100%;
    }
    #map,#map2{height: 40vh; width: 100%; margin-bottom: 2rem;}

    .navbar{
        background-color:#11A0DC;
        color: white;
    }
    .modal {
    z-index: 20;
    }
    .modal-backdrop{
        z-index: 10;
    }
    #addTripform {
        color: #333;
       
    }
    .form-group label { font-size: .8rem !important;}
    .footer {
        background: #FCB134;
    padding: 1.5rem 0;
    font-size: 1rem;
    color: #333;
    text-align: center; bottom:0;position: fixed;width: 100%;}
  @media only screen and (max-width: 56.25em) {
    .footer {
      padding: 8rem 0; } }
      p {
    margin-bottom: 0rem;
}

    .navbar-light .navbar-brand {
        color: #fff;
    }
    .navbar-light .navbar-nav .nav-link{
    color: #fff;
    }

   .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .show>.nav-link {
    color: #ffb605;
    }

   .navbar-nav {
        margin-left: 37rem;
    }


    .label-form,.modal-title{color:#fff;}
    .btn-lg {font-size: 1rem;}

    .loadtripbd{    
    border-radius: 2rem;
    border: .2rem solid #fff;
    background-color: #fff;
    color: #333;
    padding: 1rem;
    font-size: 1rem;
    box-shadow: 0.1rem 0.2rem 0.5rem 0.5rem rgba(0,3,51,.5);
    margin: 1rem auto ;
   
    }
    .modal-body {
        background-color: rgba(0,0,0,.1);
    }

    .tab-pane{
        background-color: rgba(0,0,0,.1);
        margin-bottom: 2rem
        
    }

    .modal-footer {
        margin-bottom: 6rem;
        background-color: rgba(0,0,0,.5);
    }
    [type=reset], [type=submit], button, html [type=button] {
    /* -webkit-appearance: button; */
    -webkit-appearance: none;
    } 
@media only screen and (max-width: 56.25em){
    .footer {
    padding: 2rem 0;
} 
}
.editTitle {
    color: #fff;
    
}
.edit-header{background: linear-gradient(to right,#ffb605, #ffb605);}
.edittripfooter {
    margin-bottom: 0rem;
    background: linear-gradient(to right,#11A0DC, #11A0DC);
    background: -webkit-linear-gradient(to right,#11A0DC, #11A0DC);
    background: -o-linear-gradient(to right,#11A0DC, #11A0DC);
    background: -moz-linear-gradient(to right,#11A0DC, #11A0DC);
    background: -ms-linear-gradient(to right,#11A0DC, #11A0DC);
}
.gettripbtn {margin-bottom: 1rem;}
.tab-content>.active{
    margin-bottom: 8rem !important;
}
.edit-body {
    background: linear-gradient(to right,#ffb605, #11A0DC);
}
.card {
    border:0;
    border-radius:0;
}
.profile{
        border-radius: 50%;
        width: 3.2rem;
        /* padding: 2rem; */
        /* height: 1rem; */

    }
 
    </style>
  </head>
  <body>

    <?php 

        include('connection.php');

            $user_id = $_SESSION['user_id'];

                    //get username and email
            $sql = "SELECT * FROM users WHERE user_id='$user_id'";

            $result = mysqli_query($link, $sql);

            $count = mysqli_num_rows($result);

            if ($count == 1) {

            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

            $username = $row['username'];
            $mobile = $row['mobile'];
            $email = $row['email'];
            $profile = $row['profilepicture'];

        } else {

            echo "There was an error retrieving the username and email from the database!";

        }
    ?>
        
      <nav class="navbar navbar-expand-lg navbar-light fixed-top rounded">
        <a class="navbar-brand" href="#">Orange cabs</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExample09">

          <ul class="navbar-nav ">
          <!-- mr-auto -->

           <li class="nav-item">
              <a class="nav-link" href="bookings.php">SEARCH<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item active">
              <a class="nav-link" href="maintrips.php">BOOK NOW </a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="profile.php">PROFILE</a>
            </li>
            <!--<li class="nav-item">
              <a class="nav-link" href="../help">HELP</a>
            </li> -->
            <li class="nav-item dropdown">

              <a class="nav-link dropdown-toggle" href="profile.php" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Logged in as <?php echo $username; ?>   
              </a>
              <div class="dropdown-menu" aria-labelledby="dropdown09">
                <a class="dropdown-item" href="#">
                    <?php 
                        if (empty($profile)) {

                            echo "<img src='profilepicture/carprofile.png'  class='profile'>";

                        } else {

                            echo "<img src='$profile' class='profile'>";


                        }
                    ?>
                </a>
                <a class="dropdown-item" href=""></a>
                <a class="dropdown-item" href="../index.php?logout=1">LOGOUT</a>
              </div>
            </li>
          </ul>

          <div class="enable-notification">
                <span class="tooltip-toggle" aria-label="Enable notification" tabindex="0" id="notification" style="float:right">
                    <i class="far fa-bell"></i>
                </span>
            </div>

            <div class="unable-notification">
                <span class="tooltip-toggle" aria-label="Unable notification" tabindex="0" id="notification" style="float:right">
                    <i class="far fa-bell"></i>
                </span>
            </div>
        </div>

      </nav>

    <main role="main" class="container" style="margin-top:5rem">

        <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
                <a class="nav-item nav-link active" id="nav-addtrip-tab" data-toggle="tab" href="#nav-addtrip" role="tab" aria-controls="nav-addtrip" aria-selected="true">ADD NEW TRIP</a>
                <a class="nav-item nav-link" id="nav-loadtrip-tab" data-toggle="tab" href="#nav-loadtrip" role="tab" aria-controls="nav-loadtrip" aria-selected="false">VIEW TRIPS</a>
                <a class="nav-item nav-link" id="nav-historytrip-tab" data-toggle="tab" href="#nav-historytrip" role="tab" aria-controls="nav-historytrip" aria-selected="false">TRIP HISTORY</a>
                <a class="nav-item nav-link" id="nav-historypay-tab" data-toggle="tab" href="#nav-historypay" role="tab" aria-controls="nav-historypay" aria-selected="false">PAYMENT HISTORY</a>
                <a class="nav-item nav-link" id="nav-message-tab" data-toggle="tab" href="#nav-message" role="tab" aria-controls="nav-message" aria-selected="false">MESSAGE</a>
                <a class="nav-item nav-link" id="nav-help-tab" data-toggle="tab" href="#nav-help" role="tab" aria-controls="nav-help" aria-selected="false">HELP</a>
                
            </div>
        </nav>

        <div class="tab-content" id="nav-tabContent">

            <div class="tab-pane fade show active" id="nav-addtrip" role="tabpanel" aria-labelledby="nav-addtrip-tab">

                <!-- add trip -->
                <form action="" id="addTripform">

                        <div class="modal-body">

                            <div id="map"></div>
                            <div id="infowindow-content">
                                <img src="" width="16" height="16" id="place-icon">
                                <span id="place-name"  class="title"></span><br>
                                <span id="place-address"></span>
                            </div>
                            <div id="addtripmessage"></div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="pickuppoint" class="label-form">PICK UP POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="pickuppoint"  name="pickuppoint" placeholder="PICK UP POINT:">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="dropofpoint" class="label-form">DROP-OFF POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="dropofpoint" placeholder="DROP-OFF POINT:" name="dropofpoint">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                        <label for="distance" class="label-form">DISTANCE:</label>
                                        <input type="text" class="form-control text-lowercase" id="distance"  readonly="readonly" name="distance" placeholder="DISTANCE:">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="duration" class="label-form">DURATION:</label>
                                        <input type="text" class="form-control text-lowercase" id="duration" readonly="readonly" placeholder="DURATION:" name="duration">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="price" class="label-form">PRICE:</label>
                                        <input type="text" class="form-control text-lowercase" id="price" readonly="readonly" placeholder="Price:" name="price">
                                    </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                <label for="date" class="text-uppercase label-form">Select Date & Time Pick up:</label>
                                    <div id="picker"> </div>
                                    <input class="form-control " type="hidden" id="result" value="" name="date" id="date"/>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="amountofriders" class="text-uppercase label-form">Amount of riders:</label>
                                    <input type="number" class="form-control text-lowercase" id="amountofriders" name="amountofriders" placeholder="Amount off riders:">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="nameofonerider" class="text-uppercase label-form">Name of one rider:</label>
                                    <input type="text" class="form-control text-lowercase" id="nameofonerider" placeholder="Name of one rider:" name="nameofonerider">
                                </div>

                            </div>

                        </div>

                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" name="addtrip" value="Create Trip">
                        </div>
                </form>

            </div>

            <div class="tab-pane fade" id="nav-loadtrip" role="tabpanel" aria-labelledby="nav-loadtrip-tab">
                 <!-- show recents trips -->
                 <div id="loadtrip"  class="">
                      
                      <!-- Ajax call to a php file-->
                </div>
            </div>

            <div class="tab-pane fade" id="nav-historytrip" role="tabpanel" aria-labelledby="nav-historytrip-tab">
                <div id="historytrip" class=" ">
                      <!-- Ajax call to a php file-->
                </div>
            </div>

            


            <div class="tab-pane fade" id="nav-help" role="tabpanel" aria-labelledby="nav-help-tab">
                 <div id="help" class="">
                     <h4>HELP</h4>
                </div>
                <p>Help<p>
            </div>

            <div class="tab-pane fade" id="nav-message" role="tabpanel" aria-labelledby="nav-message-tab">
                 <div id="message" class="">
                     <h4>REAL TIME CHAT</h4>
                   </div> 
                   
            </div>

        
             <div class="tab-pane fade" id="nav-historypay" role="tabpanel" aria-labelledby="nav-historypay-tab">
                 <div id="historypay" class="">
                     <h4>Not payment trip yet</h4>
                   </div> 
            </div>

        

            <!-- Edit form -->
            <form action="" id="Edittripform">
                <div class="modal fade" id="edittripModal" tabindex="-1" role="dialog" aria-labelledby="edittriptripTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                            <h5 class="modal-title editTitle" id="edittriptripTitle">Edit Trip:</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        
                        <div class="modal-body edit-body">

                            <div id="edittripmessage"></div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="pickuppoint2" class="">PICK UP POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="pickuppoint2"  name="pickuppoint2">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="dropofpoint2" class="">DROP-OFF POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="dropofpoint2" name="dropofpoint2">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                        <label for="distance2" class="">DISTANCE:</label>
                                        <input type="text" class="form-control text-lowercase" id="distance2"  readonly="readonly" name="distance2">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="duration2" class="">DURATION:</label>
                                        <input type="text" class="form-control text-lowercase" id="duration2" readonly="readonly"  name="duration2">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="price2" class="">PRICE:</label>
                                        <input type="text" class="form-control text-lowercase" id="price2" readonly="readonly" name="price2">
                                    </div>
                            </div>

                             <div class="form-row">
                                <div class="form-group col-md-12">
                                <label for="result2" class="text-uppercase">Date & Time Pick up:</label>
                                    <div id="picker2"> </div>
                                    <input class="form-control " type="hidden" id="result2" value="" name="date2"/>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="amountofriders2" class="text-uppercase">Amount of riders:</label>
                                    <input type="number" class="form-control text-lowercase" id="amountofriders2" name="amountofriders2">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="nameofonerider2" class="text-uppercase">Name of one rider:</label>
                                    <input type="text" class="form-control text-lowercase" id="nameofonerider2" placeholder="Name of one rider:" name="nameofonerider2">
                                </div>

                            </div>

                        </div>

                        <div class="modal-footer edittripfooter">
                            <!-- <button type="button" class="btn btn-primary"></button> -->
                            <input type="submit" class="btn btn-primary" name="edittrip" value="Update Trip">
                            <button type="button" class="btn btn-danger" id="deleteTrip">Delete</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                        </div>
                    </div>
                </div>
            </form>

            <!-- payment method form -->
            <form action="" id="paytripform">
                <div class="modal fade" id="paytripModal" tabindex="-1" role="dialog" aria-labelledby="edittriptripTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        
                        <div class="modal-body edit-body">

                            <div id="paytripmessage"></div>

                            <div class="card">
                                <div class="card-header edit-header">
                                    Pay your ride with PayPal:

                                </div>
                                <div class="card-body" style="color:#333; font-size:1.5rem;">
                                    
                                    <span class="card-title" style="font-size:1.7rem;">Price / Rand : &nbsp;</span>
                                    <input type="text" id="price3" readonly="readonly" style="border:0;">

                                </div>

                            </div>

                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary">Complete transaction</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
     
    </main>
     <?php include('../inc/footer.php');?> 

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script> -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
   
    <!-- <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script> -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.0/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="../src/js/datetimepicker.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-1SZLcvFN_cxb2HXrmtf7EhfA2O94SUs&libraries=places">
    </script> 
    <script src="maps.js"></script>
    
    <script src="mytrip.js"></script>

</body>
</html>


<!-- bookings content -->
<?php 

session_start();

if (!isset($_SESSION['user_id'])) {

    header("Location:../index.php");
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Orange Cabs | Search Trip</title>
  <link rel="shortcut icon" type="image/ico" href="../favicon.ico" />

   <style>
    html,body{
        height: 100%;
        overflow-x: hidden;
        position: relative;
    }
    body{
     background: url(../src/images/onlinebook.jpg);
     background-size: cover;
     color:#fff;
     position: relative;
     height: 100%;
    }
    #map{height: 75vh; width: 100%; margin-bottom: 2rem;}

    .navbar{
        background-color:#11A0DC;
        color: white;
    }

    .footer {
        background: #FCB134;
    padding: 1.5rem 0;
    font-size: 1rem;
    color: #333;
    text-align: center; bottom:0;position: fixed;width: 100%;}
    @media only screen and (max-width: 56.25em) {
    .footer {
      padding: 8rem 0; } }
      p {
    margin-bottom: 0rem;
    }

    .navbar-light .navbar-brand {
        color: #fff;
    }
    .navbar-light .navbar-nav .nav-link{
    color: #fff;
    }

   .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .show>.nav-link {
    color: #ffb605;
    }

    .navbar-nav {
        margin-left: 37rem;
    }

    .modal-footer {
        margin-bottom: 6rem;
        background-color: rgba(0,0,0,.5);
    }
    [type=reset], [type=submit], button, html [type=button] {
    /* -webkit-appearance: button; */
    -webkit-appearance: none;
    } 
    .form-search {
        margin-bottom: .1rem;
        margin-top: 2rem !important;
    }
        
    @media only screen and (max-width: 56.25em){
        .footer {
        padding: 2rem 0;
    } 
    }
    .btn-lg {
        line-height: 1;
    }
    #searchResults {
        margin-bottom: 0rem;
    }
    .edit-body {
    background: linear-gradient(to right,#ffb605, #11A0DC);
}
.edit-header{background: linear-gradient(to right,#ffb605, #ffb605);}
.edittripfooter {
    margin-bottom: 0rem;
    background: linear-gradient(to right,#11A0DC, #11A0DC);
}
.modal-footer {
        /* margin-bottom: 6rem; */
        background-color: rgba(0,0,0,.5);
    }

    .profile{
        border-radius: 50%;
        width: 3.2rem;
        /* padding: 2rem; */
        /* height: 1rem; */

    }
 
    </style>
  </head>
  <body>

    <?php 

        include('connection.php');

            $user_id = $_SESSION['user_id'];

                    //get username and email
            $sql = "SELECT * FROM users WHERE user_id='$user_id'";

            $result = mysqli_query($link, $sql);

            $count = mysqli_num_rows($result);

            if ($count == 1) {

            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

            $username = $row['username'];
            $mobile = $row['mobile'];
            $email = $row['email'];
            $profile = $row['profilepicture'];

        } else {

            echo "There was an error retrieving the username and email from the database!";

        }
    ?>
        
      <nav class="navbar navbar-expand-lg navbar-light fixed-top rounded">
        <a class="navbar-brand" href="#">Orange cabs</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExample09">

          <ul class="navbar-nav ">
          <!-- mr-auto -->

          <li class="nav-item active">
              <a class="nav-link" href="bookings.php">SEARCH<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="maintrips.php">BOOK NOW </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">PROFILE</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../help">HELP</a>
            </li>
            <li class="nav-item dropdown">

              <a class="nav-link dropdown-toggle" href="profile.php" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Logged in as <?php echo $username; ?>   
              </a>
              <div class="dropdown-menu" aria-labelledby="dropdown09">
                <a class="dropdown-item" href="#">
                    <?php 
                        if (empty($profile)) {

                            echo "<img src='profilepicture/carprofile.png'  class='profile'>";

                        } else {

                            echo "<img src='$profile' class='profile'>";


                        }
                    ?>
                </a>
                <a class="dropdown-item" href=""></a>
                <a class="dropdown-item" href="../index.php?logout=1">LOGOUT</a>
              </div>
            </li>
          </ul>

          <div class="enable-notification">
                <span class="tooltip-toggle" aria-label="Enable notification" tabindex="0" id="notification" style="float:right">
                    <i class="far fa-bell"></i>
                </span>
            </div>

            <!-- <div class="unable-notification">
                <span class="tooltip-toggle" aria-label="Unable notification" tabindex="0" id="notification" style="float:right">
                    <i class="far fa-bell"></i>
                </span>
            </div> -->
        </div>

      </nav>

    <main role="main" class="container" style="margin-top:5rem">

        <h3>Search available trip</h3>

        <form  id="searchform">
            <div class="form-row form-search">
                <div class="col-5">
                    <label class="sr-only" for="pickuppoint">PICK UP POINT:</label>
                    <input type="text" class="form-control" id="pickuppoint" placeholder="PICK UP POINT:" name="pickuppoint">
                </div>
                <div class="col-5">
                    <label class="sr-only" for="dropofpoint">DROP-OFF POINT:</label>
                    <input type="text" class="form-control" id="dropofpoint" placeholder="DROP-OFF POINT:" name="dropofpoint">
                </div>
                <div class="col-2">
                    <button type="submit" class="btn btn-success btn-lg">Search</button>
                </div>
            </div>
        </form>

        <!-- trips -->
        <div id="searchResults"></div>
         
        <!-- maps -->
        <div id="map"></div>
        <div id="infowindow-content">
            <img src="" width="16" height="16" id="place-icon">
            <span id="place-name"  class="title"></span><br>
            <span id="place-address"></span>
        </div>

        <!-- payment method form -->
        <form action="" id="paytripform">
                <div class="modal fade" id="paytripModal" tabindex="-1" role="dialog" aria-labelledby="edittriptripTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                            <h5 class="modal-title" id="paytriptripTitle">Choose a payment method for your  Trip:</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        
                        <div class="modal-body edit-body">

                            <div id="paytripmessage"></div>

                            <div class="form__group">
                                                <div class="form__radio-group">
                                                    <input type="radio" class="form__radio-input" id="creditcard" name="size">
                                                    <label for="creditcard" class="form__radio-label">
                                                        <span class="form__radio-button"></span>
                                                        Credit Card <i class="fab fa-cc-visa"></i><i class="fab fa-cc-mastercard"></i>
                                                    </label>
                                                </div>

                                                <div class="form__radio-group">
                                                    <input type="radio" class="form__radio-input" id="paypal" name="size">
                                                    <label for="paypal" class="form__radio-label">
                                                        <span class="form__radio-button"></span>
                                                        PayPal <i class="fab fa-cc-paypal"></i>
                                                    </label>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="cardnumber">Card Number</label>
                                                    <input type="text" class="form-control" placeholder="Card number The 16 digits on front of your
                                                    card" id="cardnumber"  name="cardnumber">
                                                    </fieldset>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="dateexpirationcard">Expiration date</label>
                                                    <input type="date" class="form-control" placeholder="" id="dateexpirationcard" name="dateexpirationcard">
                                                    </fieldset>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="cvv2">(The last 3 digits displayed on the back of your card)</label>
                                                    <input type="text" class="form-control" placeholder="CVV2 / CVCV2 "
                                                    id="cvv2" name="cvv2">
                                                    </fieldset>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="fullnameuserCard">Full Name on a Card</label>
                                                    <input type="text" class="form-control" placeholder="Full Name on a Card" id="fullnameuserCard" name="fullnameuserCard">
                                                    </fieldset>
                                                </div>
                                            </div>

                                    </div>

                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary">Complete transaction</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
     
    </main>

     <?php include('../inc/footer.php');?> 

     <!-- spinner -->
     <div id="spinner"><img src="../src/images/loader-yellow.gif"></div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-1SZLcvFN_cxb2HXrmtf7EhfA2O94SUs&libraries=places">
    </script> 
    <script src="maps.js"></script>
    
    <script src="javascript.js"></script>

</body>
</html>

      <?php 

include('connection.php');

    $user_id = $_SESSION['user_id'];

            //get username and email
    $sql = "SELECT * FROM users WHERE user_id='$user_id'";

    $result = mysqli_query($link, $sql);

    $count = mysqli_num_rows($result);

    if ($count == 1) {

    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

    $username = $row['username'];
    $mobile = $row['mobile'];
    $email = $row['email'];
    $profile = $row['profilepicture'];

} else {

    echo "There was an error retrieving the username and email from the database!";

}
?>

     <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
      <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">Orange Cabs</a>


       

          <ul class="navbar-nav ">
          <!-- mr-auto -->

           
            <!--<li class="nav-item">
              <a class="nav-link" href="../help">HELP</a>
            </li> -->
            <li class="nav-item dropdown">

              <a class="nav-link dropdown-toggle" href="profile.php" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Logged in as <?php echo $username; ?>   
              </a>
              <div class="dropdown-menu" aria-labelledby="dropdown09">
                <a class="dropdown-item" href="#">
                    <?php 
                        if (empty($profile)) {

                            echo "<img src='profilepicture/carprofile.png'  class='profile'>";

                        } else {

                            echo "<img src='$profile' class='profile'>";


                        }
                    ?>
                </a>
                <a class="dropdown-item" href=""></a>
                <a class="dropdown-item" href="../index.php?logout=1">LOGOUT</a>
              </div>
            </li>
          </ul>

          <div class="enable-notification">
                <span class="tooltip-toggle" aria-label="Enable notification" tabindex="0" id="notification" style="float:right">
                    <i class="fa fa-bell"></i>
                </span>
            </div>

            <div class="unable-notification">
                <span class="tooltip-toggle" aria-label="Unable notification" tabindex="0" id="notification" style="float:right">
                    <i class="fa fa-bell"></i>
                </span>
            </div>
        </div>

      </nav>
      
    

    <div class="container-fluid">
      <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
              <li class="nav-item">
                <a class="nav-link active" id="v-pills-addtrip-tab" data-toggle="pill" href="#v-pills-addtrip" role="tab" aria-controls="v-pills-addtrip" aria-selected="true">
                  <span data-feather="home"></span>
                  Add New Trip
                </a>
              </li>
              <li class="nav-item">
              <a class="nav-link" id="v-pills-booking-tab" data-toggle="pill" href="#v-pills-booking" role="tab" aria-controls="v-pills-loadtrip" aria-selected="true">
              <span data-feather="shopping-cart"></span>
              Search for Trip
                    </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="v-pills-loadtrip-tab" data-toggle="pill" href="#v-pills-loadtrip" role="tab" aria-controls="v-pills-loadtrip" aria-selected="true">
                  <span data-feather="shopping-cart"></span>
                  View Trips
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-historytrip" role="tab" aria-controls="v-pills-home" aria-selected="true">
                  <span data-feather="users"></span>
                  Trip History
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-historypay" role="tab" aria-controls="v-pills-home" aria-selected="true">
                  <span data-feather="bar-chart-2"></span>
                  Payment History
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-message" role="tab" aria-controls="v-pills-home" aria-selected="true">
                  <span data-feather="layers"></span>
                  Message
                </a>
              </li>

              <li class="nav-item">
                <a class="nav-link" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-home" aria-selected="true">
                  <span data-feather="layers"></span>
                  Profile
                </a>
              </li>


              <li class="nav-item">
                <a class="nav-link" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-help" role="tab" aria-controls="v-pills-home" aria-selected="true">
                  <span data-feather="layers"></span>
                  Help
                </a>
              </li>
            </ul>

          </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
          <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Orange Cabs Online Bookings</h1>
            <!-- <div class="btn-toolbar mb-2 mb-md-0">
              <div class="btn-group mr-2">
                <button class="btn btn-sm btn-outline-secondary">Share</button>
                <button class="btn btn-sm btn-outline-secondary">Export</button>
              </div>
              <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                <span data-feather="calendar"></span>
                This week
              </button>
            </div> -->
          </div>


          <!-- <h2>Add New Trip</h2>
          <div class="table-responsive"></div> -->

           <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-addtrip" role="tabpanel" aria-labelledby="v-pills-addtrip-tab">
                    ADD NEW TRIPS
                    <div class="tab-content" id="nav-tabContent">

            <div class="tab-pane fade show active" id="nav-addtrip" role="tabpanel" aria-labelledby="nav-addtrip-tab">

                <!-- add trip -->
                <form action="" id="addTripform">

                        <div class="modal-body">

                            <div id="map"></div>
                            <div id="infowindow-content">
                                <img src="" width="16" height="16" id="place-icon">
                                <span id="place-name"  class="title"></span><br>
                                <span id="place-address"></span>
                            </div>
                            <div id="addtripmessage"></div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="pickuppoint" class="label-form">PICK UP POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="pickuppoint"  name="pickuppoint" placeholder="PICK UP POINT:">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="dropofpoint" class="label-form">DROP-OFF POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="dropofpoint" placeholder="DROP-OFF POINT:" name="dropofpoint">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                        <label for="distance" class="label-form">DISTANCE:</label>
                                        <input type="text" class="form-control text-lowercase" id="distance"  readonly="readonly" name="distance" placeholder="DISTANCE:">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="duration" class="label-form">DURATION:</label>
                                        <input type="text" class="form-control text-lowercase" id="duration" readonly="readonly" placeholder="DURATION:" name="duration">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="price" class="label-form">PRICE:</label>
                                        <input type="text" class="form-control text-lowercase" id="price" readonly="readonly" placeholder="Price:" name="price">
                                    </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                <label for="date" class="text-uppercase label-form">Select Date & Time Pick up:</label>
                                    <div id="picker"> </div>
                                    <input class="form-control " type="hidden" id="result" value="" name="date" id="date"/>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="amountofriders" class="text-uppercase label-form">Amount of riders:</label>
                                    <input type="number" class="form-control text-lowercase" id="amountofriders" name="amountofriders" placeholder="Amount off riders:">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="nameofonerider" class="text-uppercase label-form">Name of one rider:</label>
                                    <input type="text" class="form-control text-lowercase" id="nameofonerider" placeholder="Name of one rider:" name="nameofonerider">
                                </div>

                            </div>

                        </div>

                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" name="addtrip" value="Create Trip">
                        </div>
                </form>

            </div>
        </div>

                </div>

                <div class="tab-pane fade" id="v-pills-loadtrip" role="tabpanel" aria-labelledby="v-pills-loadtrip-tab">
                    VIEW TRIP
                    <!-- show recents trips -->
                    <div id="loadtrip"  class="">
                            
                            <!-- Ajax call to a php file-->
                        </div>

                </div>



                        

                         <!-- payment method form -->
                <form action="" id="paytripform">
                <div class="modal fade" id="paytripModal" tabindex="-1" role="dialog" aria-labelledby="edittriptripTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                            <h5 class="modal-title" id="paytriptripTitle">Choose a payment method for your  Trip:</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        
                        <div class="modal-body edit-body">

                            <div id="paytripmessage"></div>

                            <div class="form__group">
                                                <div class="form__radio-group">
                                                    <input type="radio" class="form__radio-input" id="creditcard" name="size">
                                                    <label for="creditcard" class="form__radio-label">
                                                        <span class="form__radio-button"></span>
                                                        Credit Card <i class="fab fa-cc-visa"></i><i class="fab fa-cc-mastercard"></i>
                                                    </label>
                                                </div>

                                                <div class="form__radio-group">
                                                    <input type="radio" class="form__radio-input" id="paypal" name="size">
                                                    <label for="paypal" class="form__radio-label">
                                                        <span class="form__radio-button"></span>
                                                        PayPal <i class="fab fa-cc-paypal"></i>
                                                    </label>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="cardnumber">Card Number</label>
                                                    <input type="text" class="form-control" placeholder="Card number The 16 digits on front of your
                                                    card" id="cardnumber"  name="cardnumber">
                                                    </fieldset>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="dateexpirationcard">Expiration date</label>
                                                    <input type="date" class="form-control" placeholder="" id="dateexpirationcard" name="dateexpirationcard">
                                                    </fieldset>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="cvv2">(The last 3 digits displayed on the back of your card)</label>
                                                    <input type="text" class="form-control" placeholder="CVV2 / CVCV2 "
                                                    id="cvv2" name="cvv2">
                                                    </fieldset>
                                                </div>
                                            </div>

                                            <div>
                                                <div class="col-6">
                                                    <fieldset class="form-group form__input-icon regular on-off">
                                                    <label class="form-label" for="fullnameuserCard">Full Name on a Card</label>
                                                    <input type="text" class="form-control" placeholder="Full Name on a Card" id="fullnameuserCard" name="fullnameuserCard">
                                                    </fieldset>
                                                </div>
                                            </div>

                                    </div>

                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary">Complete transaction</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
                </div>

                <div class="tab-pane fade" id="v-pills-historytrip" role="tabpanel" aria-labelledby="v-pills-messages-tab">
                    TRIP HISTORY
                    <!-- show trips history -->
                    <div id="historytrip" class=" ">
                      <!-- Ajax call to a php file-->
                </div>
                 </div>
                <div class="tab-pane fade" id="v-pills-historypay" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                    PAYMENT HISTORY
                </div>
                <div class="tab-pane fade" id="v-pills-message" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                    MESSAGE


                </div>

                <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                    PROFILE
                    <div class="container" style="margin-top:6rem;">
                    <div class="row">
                        <div class="col-md-6">
                        <!-- upload picture -->
                        <h4 class="heading-secondary">Change your profile picture</h4>
                          <form action="#" class="form" id="profilepictureform" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col profile">

                                <?php 
                                    if(empty($profile)){

                                        echo "<img src='profilepicture/carprofile.png' alt='Photo user' class='popup__img' id='imagePreview'>";
                                    
                                    }else{

                                        echo "<img src='$profile' class='popup__img' id='imagePreview'>";


                                    }
                                ?>
                            </div>

                            <div class="col">

                                <!-- message alert -->
                                <div id="updatepicturemessage"></div> 
                                
                                <div class="form-group">
                                    
                                    <label class="form-label" for="picture">Select a picture</label>
                                    <input type="file" class="" id="picture" placeholder="upload new picture" name="picture">
                                    <!-- <i class="fas fa-cloud-upload-alt icon-uploadpicture"></i> -->
                                </div>
                                

                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" name="upload" value="Upload">
                                </div>
                            </div>
                        </div>
                        

                        
                    </form>     
                </div>

                <div class="col-md-6">

                    <div class="profile-content">
                        <div class="popup__right">
                            <h4 class="heading-secondary u-margin-bottom-small">Profile Settings</h4>
                            <h3 class="heading-tertiary u-margin-bottom-small"></h3>
                            <div class="popup__text">
                                <table class="popup__table">
                                    <tr>
                                        <td>Username</td>
                                        <td><?php echo $username; ?></td>
                                        <td><a href="#updateusernameModal" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr>

                                    <tr>
                                        <td>Contact Number</td>
                                        <td><?php echo $mobile; ?></td>
                                        <td><a href="#updatecontactnumberModal" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr>

                                    <tr>
                                        <td>Address Mail</td>
                                        <td><?php echo $email; ?></td>
                                        <td><a href="#updateemailModal" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                        
                                    </tr>

                                    <tr>
                                        <td>Password</td>
                                        <td>Hidden</td>
                                        <td><a href="#updatepasswordModal" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr>

                                    <tr>
                                        <td>Payment Method</td>
                                        <td>PayPal</td>
                                        <td><a href="#updatepaymentmethodModal" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr>

                                </table>
                            </div>

                        </div>
                    </div>
                </div>

                

            </div>

               <!-- update password -->
            <form action="#" class="form" id="updatepasswordform">
                <div class="modal fade" id="updatepasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update password:</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body edit-body">
                                <div class="form-group">
                                    <label for="currentpassword" class="col-form-label">Enter Current Password:</label>
                                    <input type="password" class="form-control" id="currentpassword" name="currentpassword">
                                </div>
                                <div class="form-group">
                                    <label for="newpassword" class="col-form-label">Choose New password:</label>
                                    <input type="password" class="form-control" id="newpassword" name="newpassword">
                                </div>

                                <div class="form-group">
                                    <label for="confirmpassword" class="col-form-label">Confirm password:</label>
                                    <input type="password" class="form-control" id="confirmpassword" name="confirmpassword">
                                </div>
                            </div>
                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary" name="updatepassword" id="updatepassword">Update</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </form>


            <!-- contact number -->
            <form action="#" class="form" id="updatemobilenumber">
                <div class="modal fade" id="updatecontactnumberModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update your contact number:</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body edit-body">
                                <div class="form-group">
                                    <label for="mobilenumber" class="col-form-label">Enter New number:</label>
                                    <input type="text" class="form-control" id="mobilenumber" name="mobilenumber">
                                </div>
                            </div>
                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary" name="Updatemobile" id="Updatemobile">Update</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            <!-- update payment method -->
            <form action="#" class="form" id="updatemethodpayment">
                <div class="modal fade" id="updatepaymentmethodModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update your payment method:</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body edit-body">

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="payment" id="creditcardupdate" value="cc">
                                    <label class="form-check-label" for="creditcardupdate">
                                        Credit Card <i class="fab fa-cc-visa"></i><i class="fab fa-cc-mastercard"></i>
                                    </label>
                                </div>

                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="payment" id="paypal" value="p">
                                    <label class="form-check-label" for="paypal">PayPal <i class="fab fa-cc-paypal"></i></label>
                                </div>

                                <!-- <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="payment" id="inlineRadio3" value="option3" disabled>
                                    <label class="form-check-label" for="inlineRadio3">3 (disabled)</label>
                                </div> -->
                            </div>
                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary" name="updatepayment" id="updatepayment">Update</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </form>


            <!-- update fullname -->
            <form action="#" class="form" id="updateusernameform">
                <div class="modal fade" id="updateusernameModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update  Username:</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            </div>
                            <div class="modal-body edit-body">
                                <div class="form-group">
                                    <label for="username" class="col-form-label">Username:</label>
                                    <input type="text" class="form-control" id="username" name="username">
                                </div>
                            </div>
                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary" name="Updateusername" id="Updateusername">Update</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </form>

            <!-- update email -->
            <form action="#" class="form" id="updateemailform">
                <div class="modal fade" id="updateemailModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                                <h5 class="modal-title" id="exampleModalLabel">Update  Email:</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            </div>
                            <div class="modal-body edit-body">
                                <div class="form-group">
                                    <label for="email" class="col-form-label">Email Address:</label>
                                    <input type="text" class="form-control" id="email" name="email">
                                </div>
                            </div>
                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary" name="Updateemail" id="Updateemail">Update</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                </div>
                </div>
            </form>
                
                </div>

                <div class="tab-pane fade" id="v-pills-help" role="tabpanel" aria-labelledby="v-pills-settings-tab">
                    HELP
                </div>

             <!-- Edit form -->
             <form action="" id="Edittripform">
                <div class="modal fade" id="edittripModal" tabindex="-1" role="dialog" aria-labelledby="edittriptripTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header edit-header">
                            <h5 class="modal-title editTitle" id="edittriptripTitle">Edit Trip:</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        
                        <div class="modal-body edit-body">

                            <div id="edittripmessage"></div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="pickuppoint2" class="">PICK UP POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="pickuppoint2"  name="pickuppoint2">
                                </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="dropofpoint2" class="">DROP-OFF POINT:</label>
                                    <input type="text" class="form-control text-lowercase" id="dropofpoint2" name="dropofpoint2">
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-4">
                                        <label for="distance2" class="">DISTANCE:</label>
                                        <input type="text" class="form-control text-lowercase" id="distance2"  readonly="readonly" name="distance2">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="duration2" class="">DURATION:</label>
                                        <input type="text" class="form-control text-lowercase" id="duration2" readonly="readonly"  name="duration2">
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label for="price2" class="">PRICE:</label>
                                        <input type="text" class="form-control text-lowercase" id="price2" readonly="readonly" name="price2">
                                    </div>
                            </div>

                             <div class="form-row">
                                <div class="form-group col-md-12">
                                <label for="result2" class="text-uppercase">Date & Time Pick up:</label>
                                    <div id="picker2"> </div>
                                    <input class="form-control " type="hidden" id="result2" value="" name="date2"/>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="amountofriders2" class="text-uppercase">Amount of riders:</label>
                                    <input type="number" class="form-control text-lowercase" id="amountofriders2" name="amountofriders2">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="nameofonerider2" class="text-uppercase">Name of one rider:</label>
                                    <input type="text" class="form-control text-lowercase" id="nameofonerider2" placeholder="Name of one rider:" name="nameofonerider2">
                                </div>

                            </div>

                        </div>

                        <div class="modal-footer edittripfooter">
                            <!-- <button type="button" class="btn btn-primary"></button> -->
                            <input type="submit" class="btn btn-primary" name="edittrip" value="Update Trip">
                            <button type="button" class="btn btn-danger" id="deleteTrip">Delete</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        </div>
                        </div>
                    </div>
                </div>
            </form>

            <!-- payment method form -->
            <form action="" id="paytripform">
                <div class="modal fade" id="paytripModal" tabindex="-1" role="dialog" aria-labelledby="edittriptripTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        
                        <div class="modal-body edit-body">

                            <div id="paytripmessage"></div>

                            <div class="card">
                                <div class="card-header edit-header">
                                    Pay your ride with PayPal:

                                </div>
                                <div class="card-body" style="color:#333; font-size:1.5rem;">
                                    
                                    <span class="card-title" style="font-size:1.7rem;">Price / Rand : &nbsp;</span>
                                    <input type="text" id="price3" readonly="readonly" style="border:0;">

                                </div>

                            </div>

                            <div class="modal-footer edittripfooter">
                                <button type="button" class="btn btn-primary">Complete transaction</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        
        
    </div>
    </div> 
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../src/js/jquery-3.3.1.min.js"></script>
    <script src="../src/js/popper.min.js"></script>
    <script src="../src/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.0/moment-with-locales.min.js"></script>
    <script type="text/javascript" src="../src/js/datetimepicker.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-1SZLcvFN_cxb2HXrmtf7EhfA2O94SUs&libraries=places">
    </script> 
    <script src="maps.js"></script>
    
    <script src="mytrip.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    

  </body>
</html>









