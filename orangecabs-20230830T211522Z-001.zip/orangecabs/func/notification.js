$("#comment_form").submit(function(event){

  event.preventDefault();

  var subject = $("#subject").val();
  var comment = $("#comment").val();
   var data = {
    subject: subject,
    comment: comment
   }
  // var data = $(this).serializeArray();

  // console.log(data);

  $.ajax({
    url: "notification.php",
    method: "POST",
    data: data,
    success: function(data){

      $("#notificationMessage").html("<div class='alert alert-success'>Notification Sent!</div>");

      setTimeout(function(){
        $("#comment_form")[0].reset();
      });

      setTimeout(function(){
        $("#notificationMessage").hide();
      });

    },
    error: function(){
      $("#notificationMessage").html("<div class='alert alert-danger'>Notification can't be sent try again later!</div>")
    }

  });

  // window.alert("hi");

});

// $(document).ready(function(){
 
  // updating the view with notifications using ajax
   
  function load_unseen_notification(view = '')
   
  {
   
   $.ajax({
   
    url:"fetchNotification.php",
    method:"POST",
    data:{view:view},
    dataType:"json",
    success:function(data)
   
    {
   
     $('.dropdown-menu').html(data.notification);
     
     if(data.unseen_notification > 0 && Notification.permission !== "denied")
     {
      $('.count').html(data.unseen_notification);
     }
   
    }
   
   });
   
  }
   
  load_unseen_notification();
   
  // submit form and get new records
   
  $('#comment_form').on('submit', function(event){
   event.preventDefault();
   
   if($('#subject').val() != '' && $('#comment').val() != '')
   
   {
   
    var form_data = $(this).serialize();
   
    $.ajax({
   
     url:"notification.php",
     method:"POST",
     data:form_data,
     success:function(data)
   
     {
   
      $('#comment_form')[0].reset();
      load_unseen_notification();
   
     }
   
    });
    //for nyira to use subject and comment
    $('#text').load('notification.php',
    { 
     db_subject: $('#subject').val(),
     db_message: $('#comment').val()
    });
   }
   
   else
   
   {
    alert("Both Fields are Required");
   }
   
  });
   
  // load new notifications
   
  $(document).on('click', '.dropdown-toggle', function(){
   
   $('.count').html('');
   
   load_unseen_notification('yes');
   
  });
   
  setInterval(function(){
   
   load_unseen_notification();;
   
  }, 5000);
   
  // });



  function notifyMe() {
    // Let's check if the browser supports notifications
    if (!("Notification" in window)) {
      alert("This browser does not support desktop notification");
    }
  
    // Let's check whether notification permissions have already been granted
    else if (Notification.permission === "granted") {
      // If it's okay let's create a notification
      var notification = new Notification("Hi there!");
    }
  
    // Otherwise, we need to ask the user for permission
    else if (Notification.permission !== "denied") {
      Notification.requestPermission().then(function (permission) {
        // If the user accepts, let's create a notification
        if (permission === "granted") {
          var notification = new Notification("Hi there!");
        }
        
        
      });
    }
  
    // At last, if the user has denied notifications, and you 
    // want to be respectful there is no need to bother them any more.
  }$("#comment_form").submit(function(event){

  event.preventDefault();

  var subject = $("#subject").val();
  var comment = $("#comment").val();
   var data = {
    subject: subject,
    comment: comment
   }
  // var data = $(this).serializeArray();

  // console.log(data);

  $.ajax({
    url: "notification.php",
    method: "POST",
    data: data,
    success: function(data){

      $("#notificationMessage").html("<div class='alert alert-success'>Notification Sent!</div>");

      setTimeout(function(){
        $("#comment_form")[0].reset();
      });

      setTimeout(function(){
        $("#notificationMessage").hide();
      });

    },
    error: function(){
      $("#notificationMessage").html("<div class='alert alert-danger'>Notification can't be sent try again later!</div>")
    }

  });

  // window.alert("hi");

});

// $(document).ready(function(){
 
  // updating the view with notifications using ajax
   
  function load_unseen_notification(view = '')
   
  {
   
   $.ajax({
   
    url:"fetchNotification.php",
    method:"POST",
    data:{view:view},
    dataType:"json",
    success:function(data)
   
    {
   
     $('.dropdown-menu').html(data.notification);
     
     if(data.unseen_notification > 0 && Notification.permission !== "denied")
     {
      $('.count').html(data.unseen_notification);
     }
   
    }
   
   });
   
  }
   
  load_unseen_notification();
   
  // submit form and get new records
   
  $('#comment_form').on('submit', function(event){
   event.preventDefault();
   
   if($('#subject').val() != '' && $('#comment').val() != '')
   
   {
   
    var form_data = $(this).serialize();
   
    $.ajax({
   
     url:"notification.php",
     method:"POST",
     data:form_data,
     success:function(data)
   
     {
   
      $('#comment_form')[0].reset();
      load_unseen_notification();
   
     }
   
    });
    //for nyira to use subject and comment
    $('#text').load('notification.php',
    { 
     db_subject: $('#subject').val(),
     db_message: $('#comment').val()
    });
   }
   
   else
   
   {
    alert("Both Fields are Required");
   }
   
  });
   
  // load new notifications
   
  $(document).on('click', '.dropdown-toggle', function(){
   
   $('.count').html('');
   
   load_unseen_notification('yes');
   
  });
   
  setInterval(function(){
   
   load_unseen_notification();;
   
  }, 5000);
   
  // });



  function notifyMe() {
    // Let's check if the browser supports notifications
    if (!("Notification" in window)) {
      alert("This browser does not support desktop notification");
    }
  
    // Let's check whether notification permissions have already been granted
    else if (Notification.permission === "granted") {
      // If it's okay let's create a notification
      var notification = new Notification("Hi there!");
    }
  
    // Otherwise, we need to ask the user for permission
    else if (Notification.permission !== "denied") {
      Notification.requestPermission().then(function (permission) {
        // If the user accepts, let's create a notification
        if (permission === "granted") {
          var notification = new Notification("Hi there!");
        }
        
        
      });
    }
  
    // At last, if the user has denied notifications, and you 
    // want to be respectful there is no need to bother them any more.
  }