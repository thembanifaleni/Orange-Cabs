<?php

if(isset($_POST['subject'])){

    include('connection.php');

    $subject = mysqli_real_escape_string($link,$_POST['subject']);
    $comment = mysqli_real_escape_string($link,$_POST['comment']);

    $date = date('Y-m-d H:i:s', time());
    $sql = "INSERT INTO notification(`subject`,`comment`,`date_comment`) VALUES('$subject','$comment','$date')";

    $result = mysqli_query($link,$sql);

}

?>