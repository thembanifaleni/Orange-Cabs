<?php 

session_start();
?>

<div class="row">
            <!-- sidebar navigation -->
            <? $p='profile'; include('../inc/sidebar.php');?>

            <!-- content bookings-->
            <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Online Bookings / Message  Bookings</h1>
                    <!-- <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group mr-2">
                        <button class="btn btn-sm btn-outline-secondary">Share</button>
                        <button class="btn btn-sm btn-outline-secondary">Export</button>
                    </div>
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle">
                        <span data-feather="calendar"></span>
                        This week
                    </button>
                    </div> -->
                </div>
                <div class="row">
                 <div class="col-md-6">
                    <!-- upload picture -->
                    <h4 class="heading-secondary">Change your profile picture</h4>
                    <form action="#" class="form" id="profilepictureform" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col profile">

                                <?php 
                                    if(!isset($_SESSION['profilepicture'])){

                                        echo "<img src='profilepicture/carprofile.png' alt='Photo user' class='popup__img' id='imagePreview'>";
                                    
                                    }else{

                                            echo "<img src='".$_SESSION['profilepicture']."' class='popup__img' id='imagePreview'>";


                                    }
                                ?>
                            </div>

                            <div class="col">

                                <!-- message alert -->
                                <div id="updatepicturemessage"></div> 
                                
                                <div class="form-group">
                                    
                                    <label class="form-label" for="picture">Select a picture</label>
                                    <input type="file" class="" id="picture" placeholder="upload new picture" name="picture">
                                    <!-- <i class="fas fa-cloud-upload-alt icon-uploadpicture"></i> -->
                                </div>
                                

                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" name="upload" value="Upload">
                                </div>
                            </div>
                        </div>
                        

                        
                    </form>     
                </div>

                <div class="col-md-6">

                    <div class="profile-content">
                        <div class="popup__right">
                            <h4 class="heading-secondary u-margin-bottom-small">Profile Settings</h4>
                            <h3 class="heading-tertiary u-margin-bottom-small"></h3>
                            <div class="popup__text">
                                <table class="popup__table">
                                    <tr>
                                        <td>Username</td>
                                        <td><?php if (isset($_SESSION['username'])) {
                                            # code...
                                            echo $_SESSION['username'];
                                        } ?></td>
                                        <td><a href="#updateusernameModal" class="btn btn-success" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr>

                                    <tr>
                                        <td>Contact Number</td>
                                        <td><?php if (isset($_SESSION['mobile'])) {
                                            echo $_SESSION['mobile'];
                                        }?></td>
                                        <td><a href="#updatecontactnumberModal" class="btn btn-success" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr>

                                    <tr>
                                        <td>Address Mail</td>
                                        <td><?php if (isset($_SESSION['email'])) {
                                            echo $_SESSION['email'];
                                        }?></td>
                                        <td><a href="#updateemailModal" class="btn btn-success" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                        
                                    </tr>

                                    <tr>
                                        <td>Password</td>
                                        <td><?php if (isset($_SESSION['password'])) {
                                            echo "Hidden". $_SESSION['password'];
                                        }?></td>
                                        <td><a href="#updatepasswordModal" class="btn btn-success" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr>

                                    <!-- <tr>
                                        <td>Payment Method</td>
                                        <td>PayPal</td>
                                        <td><a href="#updatepaymentmethodModal" data-toggle="modal"><i class="far fa-edit"></i></a></td>
                                    </tr> -->

                                </table>
                            </div>

                        </div>
                    </div>
                </div>

                

            </div>

            </main>      
</div>



        