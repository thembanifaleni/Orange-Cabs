<footer class="footer">
        <p>
            &copy; &nbsp;<script>
                document.write((new Date()).getFullYear());
            </script> Orange Cabs
        </p>
 </footer>