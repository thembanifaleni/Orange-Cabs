<nav class="col-md-2 d-none d-md-block bg-light sidebar">
          <div class="sidebar-sticky">
            <!-- <ul class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical"> -->
            <ul class="nav flex-column">
                <li class="nav-item <?php if($p == 'search'){echo 'active';}?>">
                  <a class="nav-link " href="?p=search">Search for Trip</a>
                </li>

                <li class="nav-item <?php if($p == 'booknow'){echo 'active';}?>">
                  <a class="nav-link " href="?p=booknow">Add New Trip</a>
                </li>

                <li class="nav-item  <?php if($p == 'viewtrip'){echo 'active';}?>">
                  <a class="nav-link" href="?p=viewtrip">View Trips</a>
                </li>

                <li class="nav-item <?php if($p == 'historytrip'){echo 'active';}?>">
                  <a class="nav-link" href="?p=historytrip">Trip History</a>
                </li>

                <li class="nav-item <?php if($p == 'payment'){echo 'active';}?>">
                  <a class="nav-link " href="?p=payment">Payment History</a>
                </li>

                <li class="nav-item  <?php if($p == 'message'){echo 'active';}?>">
                  <a class="nav-link" href="?p=message"> Message</a>
                </li>

                <li class="nav-item <?php if($p == 'profile'){echo 'active';}?>">
                  <a class="nav-link"  href="?p=profile">Profile</a>
                </li>

                <li class="nav-item <?php if($p == 'help'){echo 'active';}?>">
                  <a class="nav-link"  href="?p=help">Help</a>
                </li>
              </ul>

          </div>
        </nav>