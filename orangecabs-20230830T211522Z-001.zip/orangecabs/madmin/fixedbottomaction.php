<div class="fixed-action-btn">
    <a class="btn-floating btn-large red">
      <i class="material-icons">add</i>
    </a>

     <ul>
      <li>
        <a href="#cars-modal" class="modal-trigger btn-floating blue">
          <i class="material-icons">directions_bus</i>
        </a>
      </li>

      <!-- <li>
        <a href="#category-modal" class="modal-trigger btn-floating blue">
          <i class="material-icons">folder</i>
        </a>
      </li> -->

      <li>
        <a href="#driver-modal" class="modal-trigger btn-floating blue">
          <i class="material-icons">group_add</i>
        </a>
      </li>
    </ul>
  </div>