<footer class="section blue darken-2 white-text center">
     <p>OrangeMadmin Copyright &copy; <script>
                document.write((new Date()).getFullYear());
            </script></p>
  </footer>