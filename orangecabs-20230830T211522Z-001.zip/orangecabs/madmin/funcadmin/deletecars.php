<?php

include_once("../../func/connect.php");

if(isset($_POST['car_id'])){

    //get the id of the note through Ajax
    $car_id = $_POST['car_id'];

    // run a query to delete the trip
    $sql = "DELETE FROM cars WHERE  car_id='$car_id'";
    $result = mysqli_query($link, $sql);
    if(!$result){
        echo 'error';   
    }
}

?>