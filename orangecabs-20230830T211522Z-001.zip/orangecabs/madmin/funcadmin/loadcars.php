
                <?php
                                        include('../../func/connection.php');
                                        
                                        $sqlcars = "SELECT * FROM cars 
                                            INNER JOIN model_car 
                                            ON cars.vehicule_model = model_car.modelcar_id
                                            INNER JOIN brand_car
                                            ON cars.vehicule_brand = brand_car.brandcar_id
                                            INNER JOIN users
                                            ON cars.driver_id = users.user_id
                                            INNER JOIN colorcar
                                            ON cars.vehicule_color = colorcar.colorcar_id ORDER BY car_id DESC";
                                            

                                        if($result = mysqli_query($link, $sqlcars)){

                                            if(mysqli_num_rows($result)>0){

                                                while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
                                                $car_id = $row['car_id'];
                                                $modelcar = $row['title'];
                                                $brand_car = $row['brand_title'];
                                                $vehiculeRegistration = $row['vehicule_registration'];
                                                $vehiculeLicenceN = $row['vehicule_licenceN'];
                                                $seatavailable = $row['seatavailable'];
                                                $vehiculeColor = $row['colorcar_title'];
                                                $rateperkm = $row['rate_per_km'];
                                                $driver = $row['username'];
                                                $statusCar = $row['status_car'];
                                                // $seatavailable = $row['seatavailable'];
                                                $profile = $row['picture'];          
                                    ?>
                                    <tr>
                                        <td>
                                            <a href="#picturecars-modal" class="modal-trigger btn-floating blue" data-car-id="<?php echo $car_id ?>">
                                                <?php 
                                                    if(empty($profile)) {
                                                        echo "
                                                        <i class=\"material-icons\">system_update_alt</i> 
                                                        ";
                                                    }
                                                    else {
                                                        echo "<i class=\"material-icons\"><img src='$profile'></i>";
                                                    }     
                                                ?>
                                            </a>
                                        </td>
                                        <td><?php echo  $modelcar; ?></td>
                                        <td><?php echo $brand_car;?></td>
                                        <td><?php echo $vehiculeRegistration; ?></td>
                                        <td><?php echo $vehiculeLicenceN; ?></td>
                                        <td><?php echo $seatavailable; ?></td>
                                        <td><?php echo $vehiculeColor; ?></td>
                                        <td><?php echo $rateperkm;?></td>
                                        <td><?php echo $driver;?></td>
                                        <td>
                                        <a href="#" class="modal-trigger btn-floating blue" data-user-id="<?php echo $car_id ?>">
                                            <i class="material-icons">create</i>
                                        </a>
                                        <a href="#" class="modal-trigger btn-floating red" data-user-id="<?php echo $car_id ?>">
                                            <i class="material-icons">delete</i>
                                        </a>
                                        </td>
                                        
                                    </tr>
                                    <?php
                                    }
                                    }
                                    }
                                    ?>   