
<nav class="blue darken-2">
    <div class="container">
      <div class="nav-wrapper">
        <a href="index.php" class="brand-logo">OrangeMadmin</a>
        <a href="#" data-activates="side-nav" class="button-collapse show-on-large right">
          <i class="material-icons">menu</i>
        </a>
        <ul class="right hide-on-med-and-down">
        <li class=" <?php if($p == 'madmin'){echo 'active';}?>">
            <a href="?p=madmin">Maps</a>
          </li>

          
          <li class=" <?php if($p == 'users'){echo 'active';}?>">
            <a href="?p=users">Users</a>
          </li>

          <li class=" <?php if($p == 'drivers'){echo 'active';}?>">
            <a href="?p=drivers">Drivers</a>
          </li>

          <li>
            <a href="drivers.php"><i class="material-icons">notifications</i></a>
          </li>
        </ul>
        <!-- Side nav -->
        <ul id="side-nav" class="side-nav">
          <li>
            <div class="user-view">
              <div class="background">
                <img src="img/ocean.jpg" alt="">
              </div>
              <a href="#">
                <?php 

                      if (isset($_SESSION['profile'])) {

                        echo "<img src='",$_SESSION['profile'],"' class=''>";

                      } else {
 
                          echo "<img src='uploadmadmin/person1.jpg'  class=''>";

                      }
                    ?>
              </a>
              <a href="#">
                <span class="name white-text"><?php if(isset($_SESSION['username'])){echo $_SESSION['username'];}?></span>
              </a>
              <a href="#">
                <span class="email white-text"><?php if(isset($_SESSION['email'])){echo $_SESSION['email'];}?></span>
              </a>
            </div>
          </li>
          <li class=" <?php if($p == 'madmin'){echo 'active';}?>">
            <a href="?p=madmin">Maps</a>
          </li>
          <li class=" <?php if($p == 'users'){echo 'active';}?>">
            <a href="?p=users">Users</a>
          </li>
          <li class=" <?php if($p == 'drivers'){echo 'active';}?>">
            <a href="?p=drivers">Drivers</a>
          </li>
          <li class=" <?php if($p == 'ridres'){echo 'active';}?>">
            <a href="?p=riders">Riders</a>
          </li>
          <li class="<?php if($p == 'cars'){echo 'active';}?>">
            <a href="?p=cars">Cars</a>
          </li>
          <li class=" <?php if($p == 'payment'){echo 'active';}?>">
            <a href="?p=payment">Payments</a>
          </li>
          <li class="<?php if($p == 'chat'){echo 'active';}?>">
            <a href="?p=chat">Chat</a>
          </li>
          <li class=" <?php if($p == 'settings'){echo 'active';}?>">
            <a href="?p=settings">Settings</a>
          </li>
          <li class="">
            <a href="../index.php?logout=1">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>