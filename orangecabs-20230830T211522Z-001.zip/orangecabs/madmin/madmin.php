<?php 

// session_start();

include('../func/connection.php');

if (!isset($_SESSION['user_id'])) {

    header("Location:../index.php");
}

$sql = "SELECT * FROM users WHERE role='driver'";
$result = mysqli_query($link,$sql);


//vehicule model
$sqlmodelcar = "SELECT * FROM model_car";
$resultmodelcar = mysqli_query($link,$sqlmodelcar);

//vehicule color
$sqlcolorcar = "SELECT * FROM colorcar";
$resultcolorcar = mysqli_query($link,$sqlcolorcar);

//vehicule color
$sqlbrandcar = "SELECT * FROM brand_car";
$resultbrandcar = mysqli_query($link,$sqlbrandcar);
?>
<!DOCTYPE html>
<html>

<head>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
  <link type="text/css" rel="stylesheet" href="css/main.css" />
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>
  <!-- <link type="text/css" rel="stylesheet" href="css/datatables.min.css" /> -->

  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="shortcut icon" type="image/png" href="../favicon.ico">
  <title>OrangeMadmin</title>

</head>

<body class="grey lighten-4">


  <?=$content;?>



    <!-- Footer -->
    <?php include('footer.php');?> 

    <!-- Fixed Action Button -->
    <?php include('fixedbottomaction.php');?>

    <!-- Add Cars Modal -->
    <form id="addcarsform">
        <div id="cars-modal" class="modal">
          <div class="modal-content">
            <h4>Add Cars</h4>
            <div id="addcarsResult"></div>

            <div class="row">
                <div class="col s12 m6 l4">
                      <!-- <input type="text" id="vehiculeModel" name="vehiculeModel"> -->
                      <label for="vehiculemodel">Vehicule Model</label>
                      <select class="browser-default" name="vehiculemodel">
                        <option value="" disabled selected>Choose vehicule model</option>
                        <?php while ($row = mysqli_fetch_array($resultmodelcar)):; ?>
                        <option name="<?php echo $row['0'];?>" value="<?php echo $row['0'];?>"><?php echo $row['1'];?></option>
                        <?php endwhile;?>
                      </select>
                </div>

                <div class="col s12 m6 l4">
                          <label for="vehiculeColor">Vehicule Color</label>
                          <select class="browser-default" name="vehiculecolor">
                            <option value="" disabled selected>Choose vehicule color</option>
                            <?php while ($row = mysqli_fetch_array($resultcolorcar)):; ?>
                            <option name="<?php echo $row['0'];?>" value="<?php echo $row['0'];?>"><?php echo $row['1'];?></option>
                            <?php endwhile;?>
                          </select>
                </div>

                <div class="col s12 m6 l4">
                    <label for="vehiculeColor">Vehicule Brand</label>
                          <select class="browser-default" name="vehiculebrand">
                            <option value="" disabled selected>Choose vehicule color</option>
                            <?php while ($row = mysqli_fetch_array($resultbrandcar)):; ?>
                            <option name="<?php echo $row['0'];?>" value="<?php echo $row['0'];?>"><?php echo $row['1'];?></option>
                            <?php endwhile;?>
                          </select>
                </div>

            </div>

            <div class="row">
                <div class="col s12 m6 l4">
                  <div class="input-field">
                        <input type="text" id="vehiculeRegistrationN" name="vehiculeRegistrationN">
                        <label for="vehiculeRegistrationN">Vehicule Registration Num.</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                    <div class="input-field">
                        <input type="text" id="LicenceNum" name="LicenceNum">
                        <label for="LicenceNum">Vehicule Licence Number</label>
                    </div>
                </div>

                <div class="col s12 m6 l4">
                  <div class="input-field">
                      <input type="number" id="seatavailable" name="seatavailable">
                      <label for="title">Seat Available</label>
                  </div>
                </div>

            </div>

            <div class="row">
                <div class="col s12 m6 l4">
                    <div class="input-field">
                        <input type="text" id="rateperkm" name="rateperkm">
                        <label for="rateperkm">Rate per Km</label>
                    </div>
                </div>

                <!-- <div class="col s12 m6 l4">
                    <div class="input-field">
                        <input type="file" id="picture" name="picture">
                        <label for="picture">Select picture </label>
                    </div>
                </div> -->

                <div class="col s12 m6 l4">
                  <label>Select Driver</label>
                  <select class="browser-default" name="driver">
                    <option value="" disabled selected>Choose driver</option>
                      <?php while ($row = mysqli_fetch_array($result)):; ?>
                      <option name="<?php echo $row['0'];?>" value="<?php echo $row['0'];?>"><?php echo $row['1'];?></option>
                      <?php endwhile;?>
                  </select>
                </div>

            </div>

            <div class="modal-footer">
              <button type="submit" class="btn blue white-text">Add Car</button>
              <a href="#!" class="modal-action modal-close btn grey white-text">close</a>
            </div>
          </div>
        </div>
    </form>

      <!-- Add driver or Admin Modal -->
    <form id="adddriverform">
        <div id="driver-modal" class="modal">
          <div class="modal-content">
            <h4>Add Driver</h4>
          
            <div id="adddriverResult"></div>

              <div class="input-field">
                <input type="text" id="driverusername" name="driverusername">
                <label for="driverusername">Username</label>
              </div>

              <div class="input-field">
                <input type="text" id="name" name="name">
                <label for="name">Driver Name</label>
              </div>

              <div class="input-field">
                <input type="email" id="email" name="email">
                <label for="email">Email</label>
              </div>

              <div class="input-field">
                <input type="number" id="mobile" name="mobile">
                <label for="password">Mobile Number</label>
              </div>

              <div class="input-field">
                <input type="text" id="role" name="role" value="">
                <label for="role">Role</label>
              </div>

              <!-- <div class="input-field">
                <select>
                  <option value="" disabled selected>Select option</option>
                  <option value="1">Web Development</option>
                  <option value="2">Graphic Design</option>
                  <option value="3">Tech Gadgets</option>
                  <option value="4">Other</option>
                </select>
                  <label>Category</label>
                </div> -->
            
            <div class="modal-footer">
              <button type="submit" class="btn blue white-text">Submit</button>
              <a href="" class="modal-action modal-close btn grey white-text">close</a>
            </div>
          </div>
        </div>
    </form>


    <!-- edit or update driver -->
    <form id="updatedriverform">
        <div id="updatedriver-modal" class="modal">
          <div class="modal-content">
            <h4>Update Driver</h4>
          
            <div id="updatedriverResult"></div>

              <div class="input-field">
                <input type="text" id="driverusername2" name="driverusername2">
                <label for="driverusername2">Username</label>
              </div>

              <div class="input-field">
                <input type="text" id="name2" name="name2">
                <label for="name2">Driver Name</label>
              </div>

              <div class="input-field">
                <input type="email" id="email2" name="email2">
                <label for="email2">Email</label>
              </div>

              <div class="input-field">
                <input type="number" id="mobile2" name="mobile2">
                <label for="mobile2">Mobile Number</label>
              </div>

              <div class="input-field">
                <input type="text" id="role" name="role2" value="">
                <label for="role2">Role</label>
              </div>

              <!-- <div class="input-field">
                <select>
                  <option value="" disabled selected>Select option</option>
                  <option value="1">Web Development</option>
                  <option value="2">Graphic Design</option>
                  <option value="3">Tech Gadgets</option>
                  <option value="4">Other</option>
                </select>
                  <label>Category</label>
                </div> -->
            
            <div class="modal-footer">
              <button type="submit" class="btn blue white-text">Submit</button>
              <a href="" class="modal-action modal-close btn grey white-text">close</a>
            </div>
          </div>
        </div>
    </form>


      <!-- upload picture Admin -->
    <form id="pictureadminform">
      <div id="pictureadmin-modal" class="modal">
        <div class="modal-content">
          <h4>Update your picture</h4>
          
            <div class="input-field">
              <input type="file" id="pictureadmin">
              <label for="pictureadmin"></label>
            </div>
   
          
          <div class="modal-footer">
            <button type="submit" class="btn blue white-text">Submit</button>
            <a href="#!" class="modal-action modal-close btn blue white-text">Submit</a>
          </div>
        </div>
      </div>
    </form>

      <!-- Add picture car Modal -->
    <form id="picturecarsform">
        <div id="picturecars-modal" class="modal">
          <div class="modal-content">
            <h4>Select Picture</h4>
            
              <div class="input-field">
                <input type="file" id="picture">
                <label for="title">Select Picture</label>
              </div>
            
            <div class="modal-footer">
              <a href="#!" class="modal-action modal-close btn blue white-text">Submit</a>
            </div>
          </div>
        </div>
    </form>

    <!-- <form action="#" class="form" id="profilepictureform" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col profile">

                                <?php 
                                    // if(empty($profile)){

                                    //     echo "<img src='profilepicture/carprofile.png' alt='Photo user' class='popup__img' id='imagePreview'>";
                                    
                                    // }else{

                                    //     echo "<img src='$profile' class='popup__img' id='imagePreview'>";


                                    // }
                                ?>
                            </div>

                            <div class="col">

                                <div id="updatepicturemessage"></div>
                                
                                <div class="form-group">
                                    <label class="form-label" for="picture">Select a picture</label>
                                    <input type="file" class="" id="picture" placeholder="upload new picture" name="picture">
                                    
                                </div>
                                

                                <div class="form-group">
                                    <input type="submit" class="btn btn-primary" name="upload" value="Upload">
                                </div>
                            </div>
                        </div>
    </form>  -->

    <!-- preloader -->
    <?php include('preloader.php');?>

    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <!-- <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script> -->
    <!-- <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script> -->
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <!-- <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script> -->
    <!-- <script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script> -->
    <!-- <script src="js/datatables.min.js"></script> -->
    
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB-1SZLcvFN_cxb2HXrmtf7EhfA2O94SUs&libraries=places">
    </script>
    <script src="madmin.js"></script>
    <script src="../func/maps.js"></script>

    <script>
      // Hide Sections
      $('.section').hide();

      setTimeout(function () {
        $(document).ready(function () {
          // Show sections
          $('.section').fadeIn();

          // Hide preloader
          $('.loader').fadeOut();

          //Init Side nav
          $('.button-collapse').sideNav();

          // Init Modal
          $('.modal').modal();

          $('.modal-trigger').leanModal();

          // Init Select
          $('select').material_select();

          // Counter
          $('.count').each(function () {
            $(this).prop('Counter', 0).animate({
              Counter: $(this).text()
            }, {
                duration: 1000,
                easing: 'swing',
                step: function (now) {
                  $(this).text(Math.ceil(now));
                }
              });
          });

          // Comments - Approve & Deny
          $('.approve').click(function (e) {
            Materialize.toast('Comment Approved', 3000);
            e.preventDefault();
          });
          $('.deny').click(function (e) {
            Materialize.toast('Comment Denied', 3000);
            e.preventDefault();
          });

          // Quick Todos
          $('#todo-form').submit(function (e) {
            const output = `<li class="collection-item">
                  <div>${$('#todo').val()}
                    <a href="#!" class="secondary-content delete">
                      <i class="material-icons">close</i>
                    </a>
                  </div>
                </li>`;

            $('.todos').append(output);

            Materialize.toast('Todo Added', 3000);

            e.preventDefault();
          });

          // Delete Todos
          $('.todos').on('click', '.delete', function (e) {
            $(this).parent().parent().remove();
            Materialize.toast('Todo Removed', 3000);

            e.preventDefault();
          });

          // CKEDITOR.replace('body');

        });
      }, 1000);

    
    </script>
</body>

</html>