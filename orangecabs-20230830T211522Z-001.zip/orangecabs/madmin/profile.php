<?php 
    session_start();

    include('../func/connection.php');
    
    if (isset($_SESSION['user_id'])) {

      $user_id = $_SESSION['user_id'];

      //get username and email
      $sql = "SELECT * FROM users WHERE user_id='$user_id'";

      $result = mysqli_query($link, $sql);

      $count = mysqli_num_rows($result);

      if ($count == 1) {

      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

      $username = $row['username'];
      $mobile = $row['mobile'];
      $email = $row['email'];
      $profile = $row['profilepicture'];

      $_SESSION['username'] = $username;
      $_SESSION['mobile'] = $mobile;
      $_SESSION['email'] = $email;
      $_SESSION['profile'] = $profile;

      } else {

      echo "There was an error retrieving the username and email from the database!";

      }

    }

    $p = 'profile';
    
    include('header.php'); 

?>

<div class="row dashboard">

    <div class="col s12 m4 l3">
        <?php $p = 'profile'; include('sidebar.php');?>
    </div>

    <div class="col s12 m8 l9"> 

        <!-- Section: users -->
      <section class="section section-stats center">
          <div class="row">
            <div class="col s12 m6 l12">
              <h1>Data table jquery riders</h1>

            </div>
          </div>
      </section>

    </div>
</div>

