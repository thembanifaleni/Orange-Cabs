<?php //session_start();?>
<!-- Side nav -->
        <ul id="" class="sidenav">
          <li>
            <div class="user-view">
              <div class="background">
                <img src="img/ocean.jpg" alt="">
              </div>
              <div class="profileimage">
                    <a href="#" id="">
                    <?php 
                      if (isset($_SESSION['profile'])) {

                        echo "<img src='",$_SESSION['profile'],"' class=''>";

                      } else {
 
                          echo "<img src='uploadmadmin/person1.jpg'  class=''>";

                      }
                    ?>
                    </a>
                    <div class="profilecontent">
                        <a href="#">
                            <span class="name white-text"><?php if(isset($_SESSION['username'])){echo $_SESSION['username'];}?></span>
                        </a>
                        <a href="#">
                            <span class="email white-text"><?php if(isset($_SESSION['email'])){echo $_SESSION['email'];}?></span>
                        </a>
                    </div>
              </div>
            </div>
          </li>
          <li class="sidebar-item <?php if($p == 'madmin'){echo 'active';}?>">
            <a href="?p=madmin">View Maps</a>
          </li>
          <li class="sidebar-item <?php if($p == 'users'){echo 'active';}?>">
            <a href="?p=users">View Users / Drivers</a>
          </li>
          <li class="sidebar-item <?php if($p == 'cars'){echo 'active';}?>">
            <a href="?p=cars">View Cars / Drivers Assignement</a>
          </li>
          <li class="sidebar-item <?php if($p == 'riders'){echo 'active';}?>">
            <a href="?p=riders">View Riders Bookings Request</a>
          </li>
          <li class="sidebar-item <?php if($p == 'drivers'){echo 'active';}?>">
            <a href="?p=drivers">View Bookings Activity</a>
          </li>
          <li class="sidebar-item <?php if($p == 'payment'){echo 'active';}?>">
            <a href="?p=payment">View Payments</a>
          </li>
          <li class="sidebar-item <?php if($p == 'chat'){echo 'active';}?>">
            <a href="?p=chat">View Chats</a>
          </li>
          <li class="sidebar-item <?php if($p == 'profile'){echo 'active';}?>">
            <a href="?p=profile">Profile</a>
          </li>
          <li class="sidebar-item">
            <a href="../index.php?logout=1">Logout</a>
          </li>
        </ul>